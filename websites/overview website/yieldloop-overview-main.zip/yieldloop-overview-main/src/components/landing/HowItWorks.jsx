import React from 'react';
import { motion } from 'framer-motion';

const steps = [
  {
    number: "01",
    title: "Deposit Assets",
    description: "Deposit into your isolated, non-custodial vault. Select your strategy mix: spot trading (BTC, ETH, SOL, PAXG), LP positions, or stablecoin yield. Nothing happens without your authorization."
  },
  {
    number: "02",
    title: "Lock Parameters",
    description: "Review risk limits, slippage tolerance, and execution frequency. Once you authorize the cycle, parameters are locked. No mid-cycle changes. No intervention. Duration is fixed (typically one month)."
  },
  {
    number: "03",
    title: "Automated Execution",
    description: "Strategy bots execute trades and manage positions within your defined limits. The system may trade actively, abstain entirely, or anything in between based on market conditions."
  },
  {
    number: "04",
    title: "Settlement & Verification",
    description: "At cycle end, all positions close. Net profit is calculated after gas, slippage, and protocol fees. Platform fee applies only if profit exists. LOOP is minted from real surplus only."
  },
  {
    number: "05",
    title: "Withdraw or Compound",
    description: "Take your profits and LOOP, or reinvest for the next cycle. Full account exit is always available post-settlement. Results are final and auditable."
  }
];

export default function HowItWorks() {
  return (
    <section className="relative py-32 px-6 bg-gradient-to-b from-transparent via-gray-900/30 to-transparent">
      <div className="max-w-5xl mx-auto">
        {/* Section header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-teal-500 mb-4">The Process</p>
          <h2 className="text-3xl md:text-5xl font-light text-white mb-6">
            How <span className="text-gray-500">it works</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto text-lg font-light">
            Every cycle ends. Every result is final. Every number can be audited.
          </p>
        </motion.div>

        {/* Steps */}
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-8 md:left-12 top-0 bottom-0 w-px bg-gradient-to-b from-teal-500/50 via-blue-500/50 to-transparent" />

          <div className="space-y-12">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="relative pl-20 md:pl-28"
              >
                {/* Number circle */}
                <div className="absolute left-0 top-0 w-16 h-16 md:w-24 md:h-24 rounded-full bg-gradient-to-br from-gray-900 to-gray-800 border border-gray-700 flex items-center justify-center">
                  <span className="text-lg md:text-2xl font-light bg-gradient-to-r from-teal-400 to-blue-500 bg-clip-text text-transparent">
                    {step.number}
                  </span>
                </div>

                {/* Content */}
                <div className="pt-2">
                  <h3 className="text-xl md:text-2xl font-medium text-white mb-3">{step.title}</h3>
                  <p className="text-gray-400 font-light leading-relaxed max-w-2xl">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}