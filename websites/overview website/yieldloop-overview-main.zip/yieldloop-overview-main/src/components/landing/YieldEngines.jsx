import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Coins, DollarSign, Shield } from 'lucide-react';

const engines = [
  {
    icon: TrendingUp,
    title: "Spot Trading",
    description: "Automated spot trading on BTC, ETH, SOL, and PAXG. Buy low, sell high strategies with strict risk limits. No leverage. No derivatives. Just spot.",
    constraints: [
      "User-defined slippage limits",
      "Pre-trade liquidity checks",
      "Immediate halt on violations"
    ]
  },
  {
    icon: Coins,
    title: "LP & Yield Vaults",
    description: "Deploy capital into approved liquidity pools and vault protocols. Earn trading fees and yield. Impermanent loss is possible and disclosed.",
    constraints: [
      "Whitelisted protocols only",
      "No forced compounding",
      "Withdraw per authorization"
    ]
  },
  {
    icon: DollarSign,
    title: "Stablecoin Yield",
    description: "Lend stablecoins to approved lending markets and vaults. Lower volatility exposure, but peg risk exists. No insolvency protection.",
    constraints: [
      "Approved venues only",
      "No leverage or margin",
      "Conservative allocation limits"
    ]
  }
];

export default function YieldEngines() {
  return (
    <section className="relative py-32 px-6 bg-gradient-to-b from-transparent via-gray-900/20 to-transparent">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-teal-500 mb-4">Yield Engines</p>
          <h2 className="text-3xl md:text-5xl font-light text-white mb-6">
            Where profit <span className="text-gray-500">comes from</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg font-light">
            YieldLoop uses three core strategy modules. All operate with hard constraints. All are opt-in. None use leverage or derivatives.
          </p>
        </motion.div>

        {/* Engines */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {engines.map((engine, index) => (
            <motion.div
              key={engine.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group p-8 rounded-2xl bg-gradient-to-b from-gray-900/80 to-gray-900/40 border border-gray-800/50 hover:border-teal-500/30 transition-all duration-500"
            >
              {/* Icon */}
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-teal-500/20 to-blue-600/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <engine.icon className="w-7 h-7 text-teal-400" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-medium text-white mb-3">{engine.title}</h3>
              <p className="text-gray-400 font-light leading-relaxed mb-6">{engine.description}</p>

              {/* Constraints */}
              <div className="space-y-2">
                <p className="text-xs uppercase tracking-wider text-gray-600 mb-3">Constraints</p>
                {engine.constraints.map((constraint, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <Shield className="w-3 h-3 text-teal-600 mt-1 flex-shrink-0" />
                    <span className="text-sm text-gray-500 font-light">{constraint}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Key points */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="p-8 md:p-10 rounded-2xl border border-gray-800/50 bg-gradient-to-br from-gray-900/50 to-transparent"
        >
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-lg font-medium text-white mb-3">No Leverage</h4>
              <p className="text-gray-500 font-light text-sm leading-relaxed">
                Zero borrowing. Zero margin. Zero derivatives. Capital efficiency through selection, not multiplication.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-medium text-white mb-3">Hard Boundaries</h4>
              <p className="text-gray-500 font-light text-sm leading-relaxed">
                Every strategy has explicit limits. If limits are breached, execution halts immediately. No exceptions.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-medium text-white mb-3">Abstention Is Valid</h4>
              <p className="text-gray-500 font-light text-sm leading-relaxed">
                If market conditions don't favor action, strategies may abstain entirely. Zero activity is a correct outcome.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}