import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-6 py-20">
      {/* Gradient orb background */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] opacity-20">
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-teal-400 via-cyan-500 to-blue-600 blur-3xl" />
      </div>
      
      {/* Grid pattern overlay */}
      <div 
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: '60px 60px'
        }}
      />

      <div className="relative z-10 max-w-5xl mx-auto text-center">
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="mb-12"
        >
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_6941e4c2f08b371ab7b96903/7255a49e0_F0B395C3-0C49-4C59-AD35-9BF5BC3203A8.png"
            alt="YieldLoop"
            className="w-28 h-28 mx-auto"
          />
        </motion.div>

        {/* Coming Soon Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mb-6"
        >
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-400 text-sm font-light">
            <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
            Coming Soon
          </span>
        </motion.div>

        {/* Main heading */}
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-7xl lg:text-8xl font-light tracking-tight mb-8"
        >
          <span className="text-white">Yield</span>
          <span className="bg-gradient-to-r from-teal-400 to-blue-500 bg-clip-text text-transparent">Loop</span>
        </motion.h1>

        {/* Tagline */}
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-xl md:text-2xl text-gray-400 font-light max-w-2xl mx-auto mb-6 leading-relaxed"
        >
          A system that doesn't lie about whether it worked.
        </motion.p>

        {/* Sub-tagline */}
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-base md:text-lg text-gray-500 font-light max-w-xl mx-auto mb-6"
        >
          Cycle-based trading. Verified profit only. No emissions. No promises.
        </motion.p>

        {/* Prelaunch notice */}
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.55 }}
          className="text-sm text-teal-400/80 font-light max-w-lg mx-auto mb-12"
        >
          Currently in design and prelaunch phase. Join our community to follow progress and participate in early discussions.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Button 
            onClick={() => {
              document.getElementById('contact-section')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="group px-8 py-6 text-base bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-400 hover:to-blue-500 text-white rounded-full border-0 transition-all duration-300 shadow-lg shadow-teal-500/20 hover:shadow-teal-500/30"
          >
            Contact Us
            <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Button>
          
          <Button 
            asChild
            variant="outline"
            className="px-8 py-6 text-base bg-transparent border border-gray-700 text-gray-300 hover:bg-white/5 hover:border-gray-600 rounded-full transition-all duration-300"
          >
            <a href="https://github.com/tkoletsky1973/YieldLoop/blob/main/docs/whitepaper/Whitepaper%20(long).md" target="_blank" rel="noopener noreferrer">
              <FileText className="mr-2 w-4 h-4" />
              Read Whitepaper
            </a>
          </Button>
        </motion.div>

        {/* Trust indicators */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="mt-20 pt-12 border-t border-gray-800/50"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-gray-600 mb-6">Built on principles</p>
          <div className="flex flex-wrap justify-center gap-8 md:gap-16 text-sm text-gray-500">
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
              Non-custodial
            </span>
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
              No leverage
            </span>
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
              No emissions
            </span>
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
              Verified profit only
            </span>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div 
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="w-6 h-10 rounded-full border border-gray-700 flex items-start justify-center p-2"
        >
          <div className="w-1 h-2 rounded-full bg-gray-500" />
        </motion.div>
      </motion.div>
    </section>
  );
}