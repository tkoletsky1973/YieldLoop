import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Clock, Zap, Lock } from 'lucide-react';

const principles = [
  {
    icon: Shield,
    title: "Truth Over Narrative",
    description: "No APYs. No projections. Only verified, realized profit after all costs are settled."
  },
  {
    icon: Clock,
    title: "Discrete Cycles",
    description: "Fixed execution windows with clear start and end. Every cycle settles completely. No rolling assumptions."
  },
  {
    icon: Zap,
    title: "No Emissions",
    description: "LOOP is minted only from real profit. No inflation schedule. No reward dilution. No death spiral."
  },
  {
    icon: Lock,
    title: "Non-Custodial Vaults",
    description: "Your assets stay in your isolated vault. No pooled funds. No cross-user risk. Full ownership."
  }
];

export default function Principles() {
  return (
    <section className="relative py-32 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-teal-500 mb-4">Core Principles</p>
          <h2 className="text-3xl md:text-5xl font-light text-white mb-6">
            Designed to <span className="text-gray-500">survive reality</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto text-lg font-light">
            Most platforms fail because they measure success using estimates instead of reality. YieldLoop refuses to lie.
          </p>
        </motion.div>

        {/* Principles grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {principles.map((principle, index) => (
            <motion.div
              key={principle.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative p-8 md:p-10 rounded-2xl bg-gradient-to-b from-gray-900/80 to-gray-900/40 border border-gray-800/50 hover:border-gray-700/50 transition-all duration-500"
            >
              {/* Icon */}
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-500/20 to-blue-600/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <principle.icon className="w-6 h-6 text-teal-400" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-medium text-white mb-3">{principle.title}</h3>
              <p className="text-gray-400 font-light leading-relaxed">{principle.description}</p>

              {/* Hover glow */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-teal-500/5 to-blue-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </motion.div>
          ))}
        </div>

        {/* Quote */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-20 text-center"
        >
          <blockquote className="text-2xl md:text-3xl font-light text-gray-300 max-w-3xl mx-auto leading-relaxed">
            "If profit cannot be verified, it does not exist."
          </blockquote>
        </motion.div>
      </div>
    </section>
  );
}