import React from 'react';
import { motion } from 'framer-motion';
import { Users, Gift, Link2, Award } from 'lucide-react';

export default function ReferralProgram() {
  return (
    <section className="relative py-32 px-6 bg-gradient-to-b from-transparent via-gray-900/30 to-transparent">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-teal-500 mb-4">Growth Programs</p>
          <h2 className="text-3xl md:text-5xl font-light text-white mb-6">
            Referral <span className="text-gray-500">programs</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg font-light">
            Bounded, non-inflationary rewards for organic growth. No ponzi mechanics. No perpetual payouts.
          </p>
        </motion.div>

        {/* Programs */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Presale Referral */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="p-8 md:p-10 rounded-2xl bg-gradient-to-br from-purple-500/10 via-gray-900/80 to-gray-900/40 border border-purple-500/20"
          >
            <div className="flex items-start justify-between mb-6">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-500/30 to-purple-600/20 flex items-center justify-center">
                <Gift className="w-7 h-7 text-purple-400" />
              </div>
              <div className="px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/30">
                <span className="text-xs font-medium text-purple-400">Pre-Launch</span>
              </div>
            </div>

            <h3 className="text-2xl font-medium text-white mb-4">Presale Referral</h3>
            <p className="text-gray-400 font-light leading-relaxed mb-8">
              Bootstrap early community through verified human referrals. Milestone-based, not volume-based. Ends at launch.
            </p>

            {/* Tiers */}
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-gray-900/50 border border-gray-800/50">
                <div className="flex items-center gap-3 mb-2">
                  <Award className="w-5 h-5 text-purple-400" />
                  <span className="text-white font-medium">Tier 1: Early Outreach</span>
                </div>
                <p className="text-sm text-gray-500 font-light ml-8">
                  25 verified humans → 1 Supporter NFT (first 10 to reach)
                </p>
              </div>

              <div className="p-4 rounded-xl bg-gray-900/50 border border-gray-800/50">
                <div className="flex items-center gap-3 mb-2">
                  <Award className="w-5 h-5 text-amber-400" />
                  <span className="text-white font-medium">Tier 2: Early Leadership</span>
                </div>
                <p className="text-sm text-gray-500 font-light ml-8">
                  100 verified humans → 1 Governor NFT (first 3 to reach)
                </p>
              </div>
            </div>

            <div className="mt-6 p-4 rounded-xl bg-purple-500/5 border border-purple-500/20">
              <p className="text-xs text-purple-400 font-light">
                Verification required: Real humans, community engagement, no bots or fake accounts. Eligibility may be revoked for abuse.
              </p>
            </div>
          </motion.div>

          {/* Post-Launch Referral */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="p-8 md:p-10 rounded-2xl bg-gradient-to-br from-teal-500/10 via-gray-900/80 to-gray-900/40 border border-teal-500/20"
          >
            <div className="flex items-start justify-between mb-6">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-teal-500/30 to-teal-600/20 flex items-center justify-center">
                <Link2 className="w-7 h-7 text-teal-400" />
              </div>
              <div className="px-3 py-1 rounded-full bg-teal-500/20 border border-teal-500/30">
                <span className="text-xs font-medium text-teal-400">Post-Launch</span>
              </div>
            </div>

            <h3 className="text-2xl font-medium text-white mb-4">Post-Launch Referral</h3>
            <p className="text-gray-400 font-light leading-relaxed mb-8">
              Reward successful referrals after platform launch. Credits sourced from platform fees. Bounded and non-recurring.
            </p>

            {/* How it works */}
            <div className="space-y-4 mb-6">
              <div className="flex items-start gap-3">
                <Users className="w-5 h-5 text-teal-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-white font-medium mb-1">Get a Referral Code</p>
                  <p className="text-sm text-gray-500 font-light">
                    Issued after completing your first deposit and execution cycle
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Gift className="w-5 h-5 text-teal-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-white font-medium mb-1">5% of Platform Fees</p>
                  <p className="text-sm text-gray-500 font-light">
                    Earn credits from referred user's first 6 positive cycles
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Award className="w-5 h-5 text-teal-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-white font-medium mb-1">Capped & Non-Recurring</p>
                  <p className="text-sm text-gray-500 font-light">
                    After 6 cycles, no further credits accrue for that referral
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-teal-500/5 border border-teal-500/20">
              <p className="text-xs text-teal-400 font-light">
                Credits are promotional offsets, not income. Self-referrals and circular patterns are rejected. May be modified or paused.
              </p>
            </div>
          </motion.div>
        </div>

        {/* Key principle */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="p-8 rounded-2xl border border-gray-800/50 bg-gradient-to-br from-gray-900/50 to-transparent text-center"
        >
          <p className="text-lg text-gray-300 font-light max-w-2xl mx-auto">
            Referral programs are <span className="text-white font-medium">optional, bounded, and fee-sourced</span>. 
            They reward real growth without distorting the core execution engine.
          </p>
        </motion.div>
      </div>
    </section>
  );
}