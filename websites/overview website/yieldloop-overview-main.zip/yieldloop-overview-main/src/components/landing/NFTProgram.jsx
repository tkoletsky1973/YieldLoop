import React from 'react';
import { motion } from 'framer-motion';
import { Crown, Users, Percent, Lock, Shield } from 'lucide-react';

export default function NFTProgram() {
  return (
    <section className="relative py-32 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-teal-500 mb-4">NFT Program</p>
          <h2 className="text-3xl md:text-5xl font-light text-white mb-6">
            Optional <span className="text-gray-500">utility layer</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg font-light">
            NFTs provide fee discounts and access. They don't affect execution, strategy performance, or profit calculation.
          </p>
        </motion.div>

        {/* NFT Tiers */}
        <div className="grid md:grid-cols-2 gap-8">
          {/* Supporter NFT */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="group relative p-8 md:p-10 rounded-2xl bg-gradient-to-br from-blue-500/10 via-gray-900/80 to-gray-900/40 border border-blue-500/20 hover:border-blue-500/40 transition-all duration-500"
          >
            {/* Badge */}
            <div className="absolute top-6 right-6">
              <div className="px-3 py-1 rounded-full bg-blue-500/20 border border-blue-500/30">
                <span className="text-xs font-medium text-blue-400">Public</span>
              </div>
            </div>

            {/* Icon */}
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500/30 to-blue-600/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
              <Users className="w-8 h-8 text-blue-400" />
            </div>

            <h3 className="text-2xl font-medium text-white mb-2">Supporter NFT</h3>
            <p className="text-blue-400 text-lg font-light mb-6">~$300 USD (BNB-denominated)</p>

            <p className="text-gray-400 font-light leading-relaxed mb-8">
              General-purpose utility NFT for YieldLoop supporters. Freely transferable with unlimited supply.
            </p>

            {/* Benefits */}
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                  <Percent className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <p className="text-white font-medium mb-1">5% Fee Discount</p>
                  <p className="text-gray-500 text-sm font-light">Applied at settlement on profitable cycles only</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                  <Shield className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <p className="text-white font-medium mb-1">Community Access</p>
                  <p className="text-gray-500 text-sm font-light">Supporter-only channels and features</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Governor NFT */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="group relative p-8 md:p-10 rounded-2xl bg-gradient-to-br from-amber-500/10 via-gray-900/80 to-gray-900/40 border border-amber-500/20 hover:border-amber-500/40 transition-all duration-500"
          >
            {/* Badge */}
            <div className="absolute top-6 right-6">
              <div className="px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/30">
                <span className="text-xs font-medium text-amber-400">Bestowed</span>
              </div>
            </div>

            {/* Icon */}
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/30 to-amber-600/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
              <Crown className="w-8 h-8 text-amber-400" />
            </div>

            <h3 className="text-2xl font-medium text-white mb-2">Governor NFT</h3>
            <p className="text-amber-400 text-lg font-light mb-6">Not publicly sold</p>

            <p className="text-gray-400 font-light leading-relaxed mb-8">
              Role-based advisory NFT for trusted participants. Non-transferable by default. Limited supply. May be revoked.
            </p>

            {/* Benefits */}
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                  <Percent className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <p className="text-white font-medium mb-1">10% Fee Discount</p>
                  <p className="text-gray-500 text-sm font-light">Overrides Supporter discount if both held</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                  <Shield className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <p className="text-white font-medium mb-1">Advisory Role</p>
                  <p className="text-gray-500 text-sm font-light">Strategy review, risk analysis, governance input</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                  <Lock className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <p className="text-white font-medium mb-1">Bounty Eligible</p>
                  <p className="text-gray-500 text-sm font-light">Eligible for discretionary bounties (not guaranteed)</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Important note */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-12 p-6 rounded-xl bg-gray-900/50 border border-gray-800/50"
        >
          <p className="text-sm text-gray-500 font-light text-center">
            <span className="text-gray-400 font-medium">Important:</span> NFTs don't affect execution logic, strategy behavior, or LOOP issuance. 
            Discounts apply only to platform fees on profitable cycles. Removal of the NFT system doesn't affect core platform operation.
          </p>
        </motion.div>
      </div>
    </section>
  );
}