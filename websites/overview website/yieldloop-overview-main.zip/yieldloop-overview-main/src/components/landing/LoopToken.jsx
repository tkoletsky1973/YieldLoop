import React from 'react';
import { motion } from 'framer-motion';
import { Check, X } from 'lucide-react';

const isItems = [
  "A record of verified, retained surplus",
  "Minted only after profit is real",
  "Proportional to completed system success",
  "Potentially redeemable when conditions allow"
];

const isNotItems = [
  "A reward or incentive token",
  "Pre-minted or scheduled for emissions",
  "A promise of future returns",
  "Price-supported or guaranteed"
];

export default function LoopToken() {
  return (
    <section className="relative py-32 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-teal-500 mb-4">The Token</p>
          <h2 className="text-3xl md:text-5xl font-light text-white mb-6">
            What <span className="bg-gradient-to-r from-teal-400 to-blue-500 bg-clip-text text-transparent">LOOP</span> actually is
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg font-light">
            LOOP is not designed to excite. It is designed to be boring, honest, and irreversible.
          </p>
        </motion.div>

        {/* Is / Is Not Grid */}
        <div className="grid md:grid-cols-2 gap-8 md:gap-12">
          {/* What LOOP IS */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="p-8 md:p-10 rounded-2xl bg-gradient-to-b from-teal-500/10 to-transparent border border-teal-500/20"
          >
            <h3 className="text-lg font-medium text-teal-400 mb-8 uppercase tracking-wide">LOOP is</h3>
            <ul className="space-y-5">
              {isItems.map((item, index) => (
                <li key={index} className="flex items-start gap-4">
                  <div className="w-6 h-6 rounded-full bg-teal-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Check className="w-4 h-4 text-teal-400" />
                  </div>
                  <span className="text-gray-300 font-light">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* What LOOP IS NOT */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="p-8 md:p-10 rounded-2xl bg-gradient-to-b from-gray-800/50 to-transparent border border-gray-700/50"
          >
            <h3 className="text-lg font-medium text-gray-500 mb-8 uppercase tracking-wide">LOOP is not</h3>
            <ul className="space-y-5">
              {isNotItems.map((item, index) => (
                <li key={index} className="flex items-start gap-4">
                  <div className="w-6 h-6 rounded-full bg-gray-700/50 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <X className="w-4 h-4 text-gray-500" />
                  </div>
                  <span className="text-gray-500 font-light">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>

        {/* Accounting floor explanation */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-16 p-8 md:p-12 rounded-2xl bg-gradient-to-r from-gray-900/80 to-gray-900/40 border border-gray-800/50 text-center"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-gray-500 mb-4">The Accounting Floor</p>
          <p className="text-xl md:text-2xl font-light text-white mb-4">
            Total Verified Retained Surplus ÷ Total LOOP Supply
          </p>
          <p className="text-gray-400 font-light max-w-xl mx-auto">
            The floor cannot erode by design. If YieldLoop succeeds, LOOP becomes a historical record of that success. If it fails, LOOP exposes that failure without disguise.
          </p>
        </motion.div>
      </div>
    </section>
  );
}