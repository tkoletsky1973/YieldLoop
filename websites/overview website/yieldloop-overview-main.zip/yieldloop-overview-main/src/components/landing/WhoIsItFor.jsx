import React from 'react';
import { motion } from 'framer-motion';
import { UserCheck, UserX } from 'lucide-react';

const forItems = [
  "Those who don't want to babysit positions or chase yields",
  "Novices who want guardrails, not promises",
  "Experienced DeFi users tired of emissions and games",
  "Long-term thinkers who see LOOP for what it is"
];

const notForItems = [
  "Anyone looking for guaranteed or predictable returns",
  "Yield chasers and APY optimizers",
  "Users who expect intervention or overrides",
  "Anyone unwilling to accept zero as a valid outcome"
];

export default function WhoIsItFor() {
  return (
    <section className="relative py-32 px-6 bg-gradient-to-b from-transparent via-gray-900/30 to-transparent">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="text-xs uppercase tracking-[0.3em] text-teal-500 mb-4">Audience</p>
          <h2 className="text-3xl md:text-5xl font-light text-white mb-6">
            Is YieldLoop <span className="text-gray-500">for you?</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto text-lg font-light">
            YieldLoop was not built to compete for attention. It was built to survive reality.
          </p>
        </motion.div>

        {/* Two columns */}
        <div className="grid md:grid-cols-2 gap-8 md:gap-12">
          {/* For */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="p-8 md:p-10 rounded-2xl border border-gray-800/50"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-full bg-teal-500/20 flex items-center justify-center">
                <UserCheck className="w-5 h-5 text-teal-400" />
              </div>
              <h3 className="text-lg font-medium text-white">YieldLoop is for</h3>
            </div>
            <ul className="space-y-4">
              {forItems.map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-2.5 flex-shrink-0" />
                  <span className="text-gray-300 font-light">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Not For */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="p-8 md:p-10 rounded-2xl border border-gray-800/50"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-full bg-gray-700/50 flex items-center justify-center">
                <UserX className="w-5 h-5 text-gray-500" />
              </div>
              <h3 className="text-lg font-medium text-white">YieldLoop is not for</h3>
            </div>
            <ul className="space-y-4">
              {notForItems.map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-gray-600 mt-2.5 flex-shrink-0" />
                  <span className="text-gray-500 font-light">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>

        {/* Final statement */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-16 text-center"
        >
          <p className="text-xl md:text-2xl font-light text-gray-300 max-w-2xl mx-auto leading-relaxed">
            "YieldLoop is not built to impress. It is built to endure."
          </p>
        </motion.div>
      </div>
    </section>
  );
}