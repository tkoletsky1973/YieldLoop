import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, FileText, Mail, MessageCircle, Github } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Footer() {
  return (
    <footer className="relative py-24 px-6" role="contentinfo">
      {/* Contact Section */}
      <motion.div 
        id="contact-section"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="max-w-4xl mx-auto text-center mb-20"
      >
        <div className="mb-8">
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-400 text-sm font-light">
            <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
            Platform Coming Soon
          </span>
        </div>
        <h2 className="text-3xl md:text-5xl font-light text-white mb-6">
          Get in touch
        </h2>
        <p className="text-gray-400 text-lg font-light mb-10 max-w-xl mx-auto">
          We're in prelaunch. Reach out with questions, feedback, or to join the early community.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
          {/* Email */}
          <motion.a
            href="mailto:founder@yieldloop.io"
            whileHover={{ scale: 1.02 }}
            className="group p-8 rounded-2xl bg-gradient-to-br from-gray-800/50 to-gray-900/50 border border-gray-700/50 hover:border-teal-500/30 transition-all duration-300"
          >
            <Mail className="w-8 h-8 mx-auto mb-4 text-teal-400" />
            <h3 className="text-white font-light text-lg mb-2">Email</h3>
            <p className="text-gray-400 text-sm">founder@yieldloop.io</p>
          </motion.a>

          {/* Discord */}
          <motion.a
            href="https://discord.gg/vARwn9yEET"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.02 }}
            className="group p-8 rounded-2xl bg-gradient-to-br from-gray-800/50 to-gray-900/50 border border-gray-700/50 hover:border-teal-500/30 transition-all duration-300"
          >
            <MessageCircle className="w-8 h-8 mx-auto mb-4 text-teal-400" />
            <h3 className="text-white font-light text-lg mb-2">Discord</h3>
            <p className="text-gray-400 text-sm">Join our community</p>
          </motion.a>

          {/* GitHub */}
          <motion.a
            href="https://github.com/tkoletsky1973/YieldLoop"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.02 }}
            className="group p-8 rounded-2xl bg-gradient-to-br from-gray-800/50 to-gray-900/50 border border-gray-700/50 hover:border-teal-500/30 transition-all duration-300"
          >
            <Github className="w-8 h-8 mx-auto mb-4 text-teal-400" />
            <h3 className="text-white font-light text-lg mb-2">GitHub</h3>
            <p className="text-gray-400 text-sm">Explore the code</p>
          </motion.a>
        </div>

        {/* Whitepaper CTA */}
        <div className="mt-12">
          <Button 
            asChild
            variant="outline"
            className="px-8 py-6 text-base bg-transparent border border-gray-700 text-gray-300 hover:bg-white/5 hover:border-gray-600 rounded-full transition-all duration-300"
          >
            <a href="https://github.com/tkoletsky1973/YieldLoop/blob/main/docs/whitepaper/Whitepaper%20(long).md" target="_blank" rel="noopener noreferrer">
              <FileText className="mr-2 w-4 h-4" />
              Read Whitepaper
            </a>
          </Button>
        </div>
      </motion.div>

      {/* Divider */}
      <div className="max-w-6xl mx-auto border-t border-gray-800/50" />

      {/* Footer content */}
      <div className="max-w-6xl mx-auto pt-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          {/* Logo and tagline */}
          <div className="flex items-center gap-4">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_6941e4c2f08b371ab7b96903/7255a49e0_F0B395C3-0C49-4C59-AD35-9BF5BC3203A8.png"
              alt="YieldLoop"
              className="w-10 h-10"
            />
            <div>
              <span className="text-white font-light text-lg">YieldLoop</span>
              <p className="text-gray-500 text-sm font-light">Survive reality.</p>
            </div>
          </div>

          {/* Links */}
          <div className="flex items-center gap-8">
            <a 
              href="https://github.com/tkoletsky1973/YieldLoop/blob/main/docs/whitepaper/Whitepaper%20(long).md" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-teal-400 transition-colors text-sm"
            >
              Whitepaper
            </a>
            <button
              onClick={() => {
                document.getElementById('contact-section')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="text-gray-400 hover:text-teal-400 transition-colors text-sm"
            >
              Contact
            </button>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-12 pt-8 border-t border-gray-800/30">
          <p className="text-gray-600 text-xs text-center max-w-3xl mx-auto leading-relaxed">
            YieldLoop does not provide investment advice. Loss of funds is possible, including total loss. 
            Past results do not predict future outcomes. LOOP is not a promise of value. 
            Read the full whitepaper and understand all risks before participating.
          </p>
        </div>

        {/* Copyright */}
        <p className="text-gray-700 text-xs text-center mt-8">
          © {new Date().getFullYear()} YieldLoop. All rights reserved.
        </p>
      </div>
    </footer>
  );
}