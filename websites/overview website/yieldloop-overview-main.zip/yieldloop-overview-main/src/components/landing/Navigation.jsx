import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { FileText, GitBranch, User, Menu, X, Activity } from 'lucide-react';

export default function Navigation({ currentPage = 'Home' }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0a0f1a]/80 backdrop-blur-xl border-b border-gray-800/50" role="navigation" aria-label="Main navigation">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to={createPageUrl('Home')} className="flex items-center gap-3 group">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_6941e4c2f08b371ab7b96903/7255a49e0_F0B395C3-0C49-4C59-AD35-9BF5BC3203A8.png"
              alt="YieldLoop"
              className="w-8 h-8"
            />
            <span className="text-xl font-light text-white group-hover:text-teal-400 transition-colors">
              YieldLoop
            </span>
          </Link>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-8">
            <Link 
              to={createPageUrl('Home')}
              className={`text-sm font-light transition-colors flex items-center gap-2 ${
                currentPage === 'Home' 
                  ? 'text-teal-400' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <FileText className="w-4 h-4" />
              Overview
            </Link>
            
            <Link 
              to={createPageUrl('Architecture')}
              className={`text-sm font-light transition-colors flex items-center gap-2 ${
                currentPage === 'Architecture' 
                  ? 'text-teal-400' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <GitBranch className="w-4 h-4" />
              Architecture
            </Link>

            <Link 
              to={createPageUrl('Simulator')}
              className={`text-sm font-light transition-colors flex items-center gap-2 ${
                currentPage === 'Simulator' 
                  ? 'text-teal-400' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Activity className="w-4 h-4" />
              Simulator
            </Link>

            <Link 
              to={createPageUrl('About')}
              className={`text-sm font-light transition-colors flex items-center gap-2 ${
                currentPage === 'About' 
                  ? 'text-teal-400' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <User className="w-4 h-4" />
              About
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-gray-400 hover:text-white transition-colors"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden overflow-hidden"
            >
              <div className="flex flex-col gap-4 pt-4 pb-2">
                <Link 
                  to={createPageUrl('Home')}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`text-sm font-light transition-colors flex items-center gap-2 ${
                    currentPage === 'Home' 
                      ? 'text-teal-400' 
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  Overview
                </Link>
                
                <Link 
                  to={createPageUrl('Architecture')}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`text-sm font-light transition-colors flex items-center gap-2 ${
                    currentPage === 'Architecture' 
                      ? 'text-teal-400' 
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <GitBranch className="w-4 h-4" />
                  Architecture
                </Link>

                <Link 
                  to={createPageUrl('Simulator')}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`text-sm font-light transition-colors flex items-center gap-2 ${
                    currentPage === 'Simulator' 
                      ? 'text-teal-400' 
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Activity className="w-4 h-4" />
                  Simulator
                </Link>

                <Link 
                  to={createPageUrl('About')}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`text-sm font-light transition-colors flex items-center gap-2 ${
                    currentPage === 'About' 
                      ? 'text-teal-400' 
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <User className="w-4 h-4" />
                  About
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
}