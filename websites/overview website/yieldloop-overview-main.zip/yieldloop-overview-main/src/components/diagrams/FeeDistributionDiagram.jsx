import React from 'react';
import { motion } from 'framer-motion';
import { Code, Megaphone, Beaker, Database, PieChart } from 'lucide-react';

const splits = [
  {
    icon: Code,
    title: 'Dev / Ops',
    percentage: '25%',
    description: 'Engineering, infrastructure, audits, maintenance',
    color: 'blue'
  },
  {
    icon: Megaphone,
    title: 'Marketing',
    percentage: '25%',
    description: 'Growth, partnerships, referral funding, bounties',
    color: 'purple'
  },
  {
    icon: Beaker,
    title: 'LoopLabs',
    percentage: '25%',
    description: 'Research, experimental strategies, long-term design',
    color: 'teal'
  },
  {
    icon: Database,
    title: 'System Deposit',
    percentage: '25%',
    description: 'Converted to LOOP, redeposited into cycles, self-funding',
    color: 'green'
  }
];

const colorMap = {
  blue: { bg: 'from-blue-500/20 to-blue-600/10', border: 'border-blue-500/30', text: 'text-blue-400' },
  purple: { bg: 'from-purple-500/20 to-purple-600/10', border: 'border-purple-500/30', text: 'text-purple-400' },
  teal: { bg: 'from-teal-500/20 to-teal-600/10', border: 'border-teal-500/30', text: 'text-teal-400' },
  green: { bg: 'from-green-500/20 to-green-600/10', border: 'border-green-500/30', text: 'text-green-400' }
};

export default function FeeDistributionDiagram() {
  return (
    <motion.section
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
    >
      {/* Section Header */}
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-light text-white mb-4">
          Platform Fee <span className="text-gray-500">Distribution</span>
        </h2>
        <p className="text-gray-400 font-light max-w-2xl mx-auto">
          Fees are collected only on profitable cycles. Split equally four ways. All allocations are transparent.
        </p>
      </div>

      {/* Visual Split */}
      <div className="max-w-5xl mx-auto mb-12">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="p-8 rounded-2xl bg-gradient-to-br from-gray-900/80 to-gray-900/40 border border-gray-800/50"
        >
          <div className="flex items-center justify-center gap-3 mb-8">
            <PieChart className="w-6 h-6 text-teal-400" />
            <h3 className="text-xl font-medium text-white">4-Way Split</h3>
          </div>

          {/* Bar visualization */}
          <div className="flex rounded-xl overflow-hidden h-16 mb-6">
            <div className="flex-1 bg-gradient-to-r from-blue-500/40 to-blue-600/40 border-r-2 border-gray-900 flex items-center justify-center">
              <span className="text-white text-sm font-medium">25%</span>
            </div>
            <div className="flex-1 bg-gradient-to-r from-purple-500/40 to-purple-600/40 border-r-2 border-gray-900 flex items-center justify-center">
              <span className="text-white text-sm font-medium">25%</span>
            </div>
            <div className="flex-1 bg-gradient-to-r from-teal-500/40 to-teal-600/40 border-r-2 border-gray-900 flex items-center justify-center">
              <span className="text-white text-sm font-medium">25%</span>
            </div>
            <div className="flex-1 bg-gradient-to-r from-green-500/40 to-green-600/40 flex items-center justify-center">
              <span className="text-white text-sm font-medium">25%</span>
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-center text-xs">
            <div className="text-blue-400">Dev / Ops</div>
            <div className="text-purple-400">Marketing</div>
            <div className="text-teal-400">LoopLabs</div>
            <div className="text-green-400">System Deposit</div>
          </div>
        </motion.div>
      </div>

      {/* Detailed Breakdown */}
      <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
        {splits.map((split, index) => (
          <motion.div
            key={split.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            className={`p-6 rounded-2xl bg-gradient-to-br ${colorMap[split.color].bg} border ${colorMap[split.color].border}`}
          >
            <div className="flex items-start gap-4">
              {/* Icon */}
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colorMap[split.color].bg} border ${colorMap[split.color].border} flex items-center justify-center flex-shrink-0`}>
                <split.icon className={`w-6 h-6 ${colorMap[split.color].text}`} />
              </div>

              {/* Content */}
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-lg font-medium text-white">{split.title}</h3>
                  <span className={`text-xl font-light ${colorMap[split.color].text}`}>{split.percentage}</span>
                </div>
                <p className="text-gray-400 font-light text-sm leading-relaxed">
                  {split.description}
                </p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Key Point */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="mt-12 p-6 rounded-xl bg-gray-900/50 border border-gray-800/50 text-center max-w-3xl mx-auto"
      >
        <p className="text-gray-300 font-light">
          System Deposit creates a <span className="text-white font-medium">perpetual internal participant</span> without emissions. 
          It grows when profitable, shrinks when not. Never subsidized.
        </p>
      </motion.div>
    </motion.section>
  );
}