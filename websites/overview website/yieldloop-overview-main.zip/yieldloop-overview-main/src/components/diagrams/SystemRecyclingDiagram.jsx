import React from 'react';
import { motion } from 'framer-motion';
import { Repeat, TrendingUp, Coins, Database, ArrowRight } from 'lucide-react';

export default function SystemRecyclingDiagram() {
  return (
    <motion.section
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
    >
      {/* Section Header */}
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-light text-white mb-4">
          Self-Sustaining <span className="text-gray-500">Loop</span>
        </h2>
        <p className="text-gray-400 font-light max-w-2xl mx-auto">
          System deposit creates a perpetual execution engine. Grows on success. Survives on patience.
        </p>
      </div>

      {/* The Loop Visualization */}
      <div className="max-w-4xl mx-auto mb-12">
        {/* Desktop circular layout */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="hidden lg:block relative p-12 rounded-3xl bg-gradient-to-br from-teal-500/5 via-gray-900/80 to-blue-500/5 border border-teal-500/20"
        >
          {/* Center Icon */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full bg-gradient-to-br from-teal-500/30 to-blue-600/30 border-2 border-teal-500/50 flex items-center justify-center">
            <Repeat className="w-10 h-10 text-teal-400 animate-spin" style={{ animationDuration: '8s' }} />
          </div>

          {/* Loop Steps in Circle */}
          <div className="relative h-96">
            {/* Step 1 - Top */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-56">
              <div className="p-4 rounded-xl bg-gray-900/80 border border-teal-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <Database className="w-4 h-4 text-teal-400" />
                  <p className="text-sm font-medium text-white">System Capital</p>
                </div>
                <p className="text-xs text-gray-400 font-light">Platform-owned LOOP + assets</p>
              </div>
            </div>

            {/* Step 2 - Right */}
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-56">
              <div className="p-4 rounded-xl bg-gray-900/80 border border-blue-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 text-blue-400" />
                  <p className="text-sm font-medium text-white">Execution Cycles</p>
                </div>
                <p className="text-xs text-gray-400 font-light">Strategies run with user + system capital</p>
              </div>
            </div>

            {/* Step 3 - Bottom */}
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-56">
              <div className="p-4 rounded-xl bg-gray-900/80 border border-green-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 text-green-400" />
                  <p className="text-sm font-medium text-white">Realized Profit</p>
                </div>
                <p className="text-xs text-gray-400 font-light">When market conditions allow</p>
              </div>
            </div>

            {/* Step 4 - Left */}
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-56">
              <div className="p-4 rounded-xl bg-gray-900/80 border border-purple-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <Coins className="w-4 h-4 text-purple-400" />
                  <p className="text-sm font-medium text-white">LOOP Minted</p>
                </div>
                <p className="text-xs text-gray-400 font-light">System's share compounds back</p>
              </div>
            </div>

            {/* Arrows */}
            <div className="absolute top-12 left-1/2 -translate-x-1/2">
              <ArrowRight className="w-5 h-5 text-teal-500 rotate-90" />
            </div>
            <div className="absolute right-12 top-1/2 -translate-y-1/2">
              <ArrowRight className="w-5 h-5 text-blue-500 rotate-90" />
            </div>
            <div className="absolute bottom-12 left-1/2 -translate-x-1/2">
              <ArrowRight className="w-5 h-5 text-green-500 rotate-180" />
            </div>
            <div className="absolute left-12 top-1/2 -translate-y-1/2">
              <ArrowRight className="w-5 h-5 text-purple-500 rotate-180" />
            </div>
          </div>
        </motion.div>

        {/* Mobile vertical layout */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="lg:hidden space-y-6"
        >
          {/* Center Icon */}
          <div className="flex justify-center mb-8">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-teal-500/30 to-blue-600/30 border-2 border-teal-500/50 flex items-center justify-center">
              <Repeat className="w-8 h-8 text-teal-400 animate-spin" style={{ animationDuration: '8s' }} />
            </div>
          </div>

          {/* Steps vertically */}
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-gray-900/80 border border-teal-500/30">
              <div className="flex items-center gap-2 mb-2">
                <Database className="w-4 h-4 text-teal-400" />
                <p className="text-sm font-medium text-white">System Capital</p>
              </div>
              <p className="text-xs text-gray-400 font-light">Platform-owned LOOP + assets</p>
            </div>

            <div className="flex justify-center">
              <ArrowRight className="w-5 h-5 text-teal-500 rotate-90" />
            </div>

            <div className="p-4 rounded-xl bg-gray-900/80 border border-blue-500/30">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-blue-400" />
                <p className="text-sm font-medium text-white">Execution Cycles</p>
              </div>
              <p className="text-xs text-gray-400 font-light">Strategies run with user + system capital</p>
            </div>

            <div className="flex justify-center">
              <ArrowRight className="w-5 h-5 text-blue-500 rotate-90" />
            </div>

            <div className="p-4 rounded-xl bg-gray-900/80 border border-green-500/30">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-green-400" />
                <p className="text-sm font-medium text-white">Realized Profit</p>
              </div>
              <p className="text-xs text-gray-400 font-light">When market conditions allow</p>
            </div>

            <div className="flex justify-center">
              <ArrowRight className="w-5 h-5 text-green-500 rotate-90" />
            </div>

            <div className="p-4 rounded-xl bg-gray-900/80 border border-purple-500/30">
              <div className="flex items-center gap-2 mb-2">
                <Coins className="w-4 h-4 text-purple-400" />
                <p className="text-sm font-medium text-white">LOOP Minted</p>
              </div>
              <p className="text-xs text-gray-400 font-light">System's share compounds back</p>
            </div>

            <div className="flex justify-center">
              <ArrowRight className="w-5 h-5 text-purple-500 rotate-90" />
            </div>

            <div className="p-3 rounded-lg bg-teal-500/10 border border-teal-500/30 text-center">
              <p className="text-xs text-teal-400 font-light">↻ Loop repeats</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Key Characteristics */}
      <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="p-6 rounded-xl bg-gray-900/50 border border-gray-800/50"
        >
          <h3 className="text-lg font-medium text-white mb-3">Can Grow</h3>
          <p className="text-gray-400 font-light text-sm leading-relaxed">
            When cycles are profitable, system capital compounds automatically
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="p-6 rounded-xl bg-gray-900/50 border border-gray-800/50"
        >
          <h3 className="text-lg font-medium text-white mb-3">Can Wait</h3>
          <p className="text-gray-400 font-light text-sm leading-relaxed">
            No pressure to trade. Zero-activity cycles don't break the system
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="p-6 rounded-xl bg-gray-900/50 border border-gray-800/50"
        >
          <h3 className="text-lg font-medium text-white mb-3">Never Subsidized</h3>
          <p className="text-gray-400 font-light text-sm leading-relaxed">
            If system loses, it shrinks. No bailouts. No printing. Just reality
          </p>
        </motion.div>
      </div>

      {/* Bottom Quote */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.9 }}
        className="mt-12 p-8 rounded-2xl bg-gradient-to-r from-gray-900/80 to-gray-900/40 border border-gray-800/50 text-center max-w-3xl mx-auto"
      >
        <p className="text-xl md:text-2xl font-light text-gray-300 leading-relaxed">
          "The system does not support price. It supports <span className="text-white font-medium">itself</span>."
        </p>
      </motion.div>
    </motion.section>
  );
}