import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, DollarSign, Minus, Check, X, Coins } from 'lucide-react';

export default function LoopMintingDiagram() {
  return (
    <motion.section
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
    >
      {/* Section Header */}
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-light text-white mb-4">
          LOOP <span className="text-gray-500">Minting Logic</span>
        </h2>
        <p className="text-gray-400 font-light max-w-2xl mx-auto">
          LOOP only exists after profit is verified. If no profit exists, nothing is minted.
        </p>
      </div>

      {/* Two Paths */}
      <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
        {/* Positive Path */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="p-8 rounded-2xl bg-gradient-to-br from-green-500/10 via-gray-900/80 to-gray-900/40 border border-green-500/20"
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
              <Check className="w-5 h-5 text-green-400" />
            </div>
            <h3 className="text-xl font-medium text-white">Positive Cycle</h3>
          </div>

          <div className="space-y-6">
            {/* Step 1 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-4 h-4 text-green-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">1. End Balance > Start Balance</p>
                <p className="text-gray-400 text-sm font-light">Positions closed. Gross gains recorded.</p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center flex-shrink-0">
                <Minus className="w-4 h-4 text-green-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">2. Deduct All Costs</p>
                <p className="text-gray-400 text-sm font-light">Gas, slippage, protocol fees subtracted.</p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center flex-shrink-0">
                <DollarSign className="w-4 h-4 text-green-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">3. Net Profit Exists</p>
                <p className="text-gray-400 text-sm font-light">Verified surplus after all costs.</p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center flex-shrink-0">
                <DollarSign className="w-4 h-4 text-green-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">4. Apply Platform Fee</p>
                <p className="text-gray-400 text-sm font-light">Fee taken from profit (NFT discounts apply).</p>
              </div>
            </div>

            {/* Step 5 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center flex-shrink-0">
                <Coins className="w-4 h-4 text-green-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">5. Mint LOOP</p>
                <p className="text-gray-400 text-sm font-light">User profit converted to LOOP. Platform fee split and deposited.</p>
              </div>
            </div>
          </div>

          <div className="mt-8 p-4 rounded-xl bg-green-500/10 border border-green-500/20">
            <p className="text-green-400 text-sm font-light">
              ✓ LOOP minted and backed by real surplus
            </p>
          </div>
        </motion.div>

        {/* Negative/Zero Path */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="p-8 rounded-2xl bg-gradient-to-br from-gray-700/10 via-gray-900/80 to-gray-900/40 border border-gray-700/20"
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-full bg-gray-600/20 flex items-center justify-center">
              <X className="w-5 h-5 text-gray-400" />
            </div>
            <h3 className="text-xl font-medium text-white">Non-Positive Cycle</h3>
          </div>

          <div className="space-y-6">
            {/* Step 1 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-lg bg-gray-600/20 flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-4 h-4 text-gray-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">1. End Balance ≤ Start Balance</p>
                <p className="text-gray-500 text-sm font-light">No gross gains, or gains too small.</p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-lg bg-gray-600/20 flex items-center justify-center flex-shrink-0">
                <Minus className="w-4 h-4 text-gray-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">2. Deduct All Costs</p>
                <p className="text-gray-500 text-sm font-light">Gas and fees may consume any gains.</p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-lg bg-gray-600/20 flex items-center justify-center flex-shrink-0">
                <X className="w-4 h-4 text-gray-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">3. No Net Profit</p>
                <p className="text-gray-500 text-sm font-light">Break-even, loss, or abstention.</p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-lg bg-gray-600/20 flex items-center justify-center flex-shrink-0">
                <X className="w-4 h-4 text-gray-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">4. No Platform Fee</p>
                <p className="text-gray-500 text-sm font-light">Fees apply only to profit.</p>
              </div>
            </div>

            {/* Step 5 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-lg bg-gray-600/20 flex items-center justify-center flex-shrink-0">
                <X className="w-4 h-4 text-gray-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">5. No LOOP Minted</p>
                <p className="text-gray-500 text-sm font-light">Cycle closes flat. Results recorded as zero.</p>
              </div>
            </div>
          </div>

          <div className="mt-8 p-4 rounded-xl bg-gray-700/10 border border-gray-700/20">
            <p className="text-gray-500 text-sm font-light">
              ✓ Valid outcome. No dilution. System waits.
            </p>
          </div>
        </motion.div>
      </div>

      {/* Formula */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.4 }}
        className="mt-12 p-8 rounded-2xl bg-gradient-to-r from-gray-900/80 to-gray-900/40 border border-gray-800/50 text-center max-w-3xl mx-auto"
      >
        <p className="text-xs uppercase tracking-wider text-gray-500 mb-4">Net Profit Formula</p>
        <p className="text-2xl font-light text-white mb-2">
          Profit = End Balance − Start Balance − Gas − Protocol Costs
        </p>
        <p className="text-gray-400 font-light">
          If Profit &gt; 0, LOOP is minted. Otherwise, outcome = 0.
        </p>
      </motion.div>
    </motion.section>
  );
}