import React from 'react';
import { motion } from 'framer-motion';
import { Vault, Bot, RefreshCw, Calculator, Coins, Database } from 'lucide-react';

const components = [
  {
    icon: Vault,
    title: 'User Vaults',
    description: 'Isolated, non-custodial. One per user. Assets never pooled.',
    position: 'top-left'
  },
  {
    icon: Bot,
    title: 'Strategy Bots',
    description: 'Execute within limits. Deterministic. No learning or adaptation.',
    position: 'top-right'
  },
  {
    icon: RefreshCw,
    title: 'Cycle Controller',
    description: 'State machine. Enforces timing. Locks/unlocks vaults.',
    position: 'middle-left'
  },
  {
    icon: Calculator,
    title: 'Settlement Engine',
    description: 'Calculates profit. Deducts costs. Triggers LOOP minting.',
    position: 'middle-right'
  },
  {
    icon: Coins,
    title: 'LOOP Contract',
    description: 'Mints only on settlement instruction. No emissions schedule.',
    position: 'bottom-left'
  },
  {
    icon: Database,
    title: 'System Deposit',
    description: 'Platform-owned capital. Reauthorized into cycles. Self-funding.',
    position: 'bottom-right'
  }
];

export default function SystemArchitectureDiagram() {
  return (
    <motion.section
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
    >
      {/* Section Header */}
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-light text-white mb-4">
          System <span className="text-gray-500">Components</span>
        </h2>
        <p className="text-gray-400 font-light max-w-2xl mx-auto">
          Separable, auditable components. No single component controls the system end-to-end.
        </p>
      </div>

      {/* Component Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {components.map((component, index) => (
          <motion.div
            key={component.title}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="group relative p-8 rounded-2xl bg-gradient-to-br from-gray-900/80 to-gray-900/40 border border-gray-800/50 hover:border-teal-500/30 transition-all duration-500"
          >
            {/* Icon */}
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-teal-500/20 to-blue-600/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
              <component.icon className="w-7 h-7 text-teal-400" />
            </div>

            {/* Content */}
            <h3 className="text-lg font-medium text-white mb-3">{component.title}</h3>
            <p className="text-gray-400 font-light text-sm leading-relaxed">
              {component.description}
            </p>
          </motion.div>
        ))}
      </div>

      {/* Data Flow */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.6 }}
        className="mt-16 max-w-4xl mx-auto"
      >
        <div className="p-8 rounded-2xl bg-gradient-to-r from-gray-900/80 to-gray-900/40 border border-gray-800/50">
          <h3 className="text-xl font-medium text-white mb-6 text-center">Data Flow (One-Way Boundaries)</h3>
          <div className="flex flex-col items-center gap-3 text-center">
            {['User Vault', 'Strategy Bots', 'Cycle Controller', 'Settlement & Accounting', 'LOOP Minting', 'User + System Deposit'].map((step, index, arr) => (
              <React.Fragment key={step}>
                <div className="px-6 py-3 rounded-lg bg-gray-800/50 border border-gray-700/50 text-gray-300 font-light">
                  {step}
                </div>
                {index < arr.length - 1 && (
                  <div className="text-teal-500 text-2xl">↓</div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </motion.div>
    </motion.section>
  );
}