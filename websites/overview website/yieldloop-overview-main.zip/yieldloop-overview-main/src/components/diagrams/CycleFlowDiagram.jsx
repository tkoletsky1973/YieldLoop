import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, Lock, Play, Calculator, CheckCircle } from 'lucide-react';

const states = [
  {
    icon: Lock,
    title: 'Inactive',
    description: 'Vault fully accessible. Configure parameters. Deposit/withdraw freely.',
    color: 'gray'
  },
  {
    icon: Lock,
    title: 'Configured',
    description: 'Parameters defined. Awaiting authorization. Still cancelable.',
    color: 'blue'
  },
  {
    icon: Play,
    title: 'Active',
    description: 'Execution live. Parameters locked. Withdrawals disabled. Strategies operating.',
    color: 'teal'
  },
  {
    icon: Calculator,
    title: 'Settlement',
    description: 'Positions closed. Costs deducted. Profit calculated. LOOP minted if profit exists.',
    color: 'purple'
  },
  {
    icon: CheckCircle,
    title: 'Post-Cycle',
    description: 'Results final. Vault unlocked. Withdraw, compound, or configure next cycle.',
    color: 'green'
  }
];

const colorMap = {
  gray: { bg: 'from-gray-500/20 to-gray-600/10', border: 'border-gray-500/30', text: 'text-gray-400' },
  blue: { bg: 'from-blue-500/20 to-blue-600/10', border: 'border-blue-500/30', text: 'text-blue-400' },
  teal: { bg: 'from-teal-500/20 to-teal-600/10', border: 'border-teal-500/30', text: 'text-teal-400' },
  purple: { bg: 'from-purple-500/20 to-purple-600/10', border: 'border-purple-500/30', text: 'text-purple-400' },
  green: { bg: 'from-green-500/20 to-green-600/10', border: 'border-green-500/30', text: 'text-green-400' }
};

export default function CycleFlowDiagram() {
  return (
    <motion.section
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
    >
      {/* Section Header */}
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-light text-white mb-4">
          Execution Cycle <span className="text-gray-500">State Machine</span>
        </h2>
        <p className="text-gray-400 font-light max-w-2xl mx-auto">
          Every cycle progresses through five discrete states. No state can be skipped or reordered.
        </p>
      </div>

      {/* Diagram */}
      <div className="max-w-4xl mx-auto">
        {states.map((state, index) => (
          <div key={state.title}>
            {/* State Card */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className={`relative p-6 rounded-2xl bg-gradient-to-br ${colorMap[state.color].bg} border ${colorMap[state.color].border}`}
            >
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colorMap[state.color].bg} border ${colorMap[state.color].border} flex items-center justify-center flex-shrink-0`}>
                  <state.icon className={`w-6 h-6 ${colorMap[state.color].text}`} />
                </div>

                {/* Content */}
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xs font-mono text-gray-500">STATE {index + 1}</span>
                    <h3 className="text-xl font-medium text-white">{state.title}</h3>
                  </div>
                  <p className="text-gray-400 font-light leading-relaxed">
                    {state.description}
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Arrow */}
            {index < states.length - 1 && (
              <div className="flex justify-center py-4">
                <ArrowDown className="w-6 h-6 text-gray-600" />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Key Point */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="mt-12 p-6 rounded-xl bg-gray-900/50 border border-gray-800/50 text-center max-w-3xl mx-auto"
      >
        <p className="text-gray-300 font-light">
          If something didn't occur within a completed cycle, <span className="text-white font-medium">it doesn't exist</span>. 
          No retries. No smoothing. No overrides.
        </p>
      </motion.div>
    </motion.section>
  );
}