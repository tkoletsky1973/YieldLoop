import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Copy, Gift, CheckCircle2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ReferralDashboard({ referralData, userId }) {
  const [copied, setCopied] = useState(false);
  
  // Generate a simulated referral code
  const referralCode = userId ? userId.substring(0, 8).toUpperCase() : 'DEMO1234';
  const referralLink = `https://yieldloop.io/signup?ref=${referralCode}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    toast.success('Referral link copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  const milestones = [
    { count: 5, reward: 'Bronze Supporter NFT', achieved: referralData.count >= 5 },
    { count: 25, reward: 'Silver Supporter NFT', achieved: referralData.count >= 25 },
    { count: 100, reward: 'Gold Supporter NFT', achieved: referralData.count >= 100 }
  ];

  return (
    <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5 text-blue-400" />
          Referral Program
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 rounded-lg bg-blue-900/10 border border-blue-800/30">
            <p className="text-sm text-gray-400 mb-1">Total Referrals</p>
            <p className="text-2xl font-light text-white">{referralData.count}</p>
          </div>
          <div className="p-4 rounded-lg bg-green-900/10 border border-green-800/30">
            <p className="text-sm text-gray-400 mb-1">Referral Credits</p>
            <p className="text-2xl font-light text-white">${referralData.credits.toFixed(2)}</p>
          </div>
        </div>

        {/* Referral Link */}
        <div>
          <p className="text-sm text-gray-400 mb-2">Your Referral Link</p>
          <div className="flex gap-2">
            <div className="flex-1 p-3 rounded-lg bg-gray-800/50 border border-gray-700 text-sm text-gray-300 truncate">
              {referralLink}
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={handleCopy}
              className="border-gray-700"
            >
              {copied ? <CheckCircle2 className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Presale Milestones */}
        <div>
          <p className="text-sm text-gray-400 mb-3">Presale Milestones</p>
          <div className="space-y-2">
            {milestones.map((milestone, idx) => (
              <div
                key={idx}
                className={`p-3 rounded-lg border ${
                  milestone.achieved
                    ? 'bg-green-900/10 border-green-800/30'
                    : 'bg-gray-800/30 border-gray-700/50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {milestone.achieved ? (
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                    ) : (
                      <Gift className="w-4 h-4 text-gray-500" />
                    )}
                    <span className="text-sm text-white">{milestone.count} Referrals</span>
                  </div>
                  <Badge variant={milestone.achieved ? 'default' : 'outline'}>
                    {milestone.reward}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Post-Launch Info */}
        <div className="p-4 rounded-lg bg-teal-900/10 border border-teal-800/30">
          <p className="text-sm text-teal-400 mb-2 font-medium">Post-Launch Rewards</p>
          <p className="text-xs text-gray-400">
            After launch, you'll earn 5% of platform fees from referred users' profitable cycles (capped over 6 cycles).
          </p>
        </div>
      </CardContent>
    </Card>
  );
}