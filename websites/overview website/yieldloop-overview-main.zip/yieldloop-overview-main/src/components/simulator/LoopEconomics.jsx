import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Coins, TrendingUp, DollarSign, ArrowUpDown } from 'lucide-react';

export default function LoopEconomics({ totalLoopMinted, totalProfit, totalLoss }) {
  // Calculate LOOP floor price (accounting floor)
  const verifiedProfit = Math.max(0, totalProfit - totalLoss);
  const loopFloorPrice = totalLoopMinted > 0 ? verifiedProfit / totalLoopMinted : 0;
  
  // Simulate market price (slightly above floor in healthy market)
  const marketPrice = loopFloorPrice > 0 ? loopFloorPrice * 1.15 : 0;
  const premium = marketPrice - loopFloorPrice;
  const premiumPercent = loopFloorPrice > 0 ? ((premium / loopFloorPrice) * 100) : 0;

  return (
    <Card className="bg-gradient-to-br from-teal-900/20 to-blue-900/20 border-teal-700/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Coins className="w-5 h-5 text-teal-400" />
          LOOP Token Economics
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Total LOOP in Circulation */}
        <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400 mb-1">Total LOOP in Circulation</p>
              <p className="text-2xl font-semibold text-white">
                {totalLoopMinted.toFixed(2)} <span className="text-sm text-gray-400">LOOP</span>
              </p>
            </div>
            <Coins className="w-10 h-10 text-teal-400 opacity-50" />
          </div>
        </div>

        {/* Floor Price */}
        <div className="p-4 rounded-lg bg-green-900/10 border border-green-700/50">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm text-gray-400 mb-1">LOOP Floor Price</p>
              <p className="text-xl font-semibold text-green-400">
                ${loopFloorPrice.toFixed(4)}
              </p>
            </div>
            <DollarSign className="w-8 h-8 text-green-400 opacity-50" />
          </div>
          <div className="text-xs text-gray-400 space-y-1">
            <p>• Backed by: ${verifiedProfit.toFixed(2)} verified profit</p>
            <p>• Formula: Verified Profit ÷ LOOP Minted</p>
            <p>• Guaranteed redemption value</p>
          </div>
        </div>

        {/* Market Price (Simulated) */}
        <div className="p-4 rounded-lg bg-blue-900/10 border border-blue-700/50">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm text-gray-400 mb-1">Simulated Market Price</p>
              <p className="text-xl font-semibold text-blue-400">
                ${marketPrice.toFixed(4)}
              </p>
            </div>
            <TrendingUp className="w-8 h-8 text-blue-400 opacity-50" />
          </div>
          {marketPrice > 0 && (
            <div className="text-xs text-gray-400 space-y-1">
              <p>• Premium over floor: ${premium.toFixed(4)} ({premiumPercent.toFixed(1)}%)</p>
              <p>• Market trades above floor in healthy conditions</p>
            </div>
          )}
        </div>

        {/* Redemption Info */}
        <div className="p-4 rounded-lg bg-gray-800/30 border border-gray-700/50">
          <div className="flex items-center gap-2 mb-2">
            <ArrowUpDown className="w-4 h-4 text-teal-400" />
            <p className="text-sm font-medium text-gray-200">Redemption Rights</p>
          </div>
          <div className="text-xs text-gray-400 space-y-1">
            <p>• You can redeem LOOP at floor price anytime</p>
            <p>• Redemption burns LOOP and returns USD from vault</p>
            <p>• Floor price = minimum guaranteed value</p>
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-lg bg-gray-800/50 border border-gray-700/50">
            <p className="text-xs text-gray-400 mb-1">Your LOOP Value</p>
            <p className="text-lg font-semibold text-white">
              ${(totalLoopMinted * loopFloorPrice).toFixed(2)}
            </p>
            <p className="text-xs text-gray-500">At floor price</p>
          </div>
          <div className="p-3 rounded-lg bg-gray-800/50 border border-gray-700/50">
            <p className="text-xs text-gray-400 mb-1">Backing Ratio</p>
            <p className="text-lg font-semibold text-teal-400">
              {totalLoopMinted > 0 ? '100%' : 'N/A'}
            </p>
            <p className="text-xs text-gray-500">Fully backed</p>
          </div>
        </div>

        {totalLoopMinted === 0 && (
          <div className="text-center py-6">
            <Coins className="w-12 h-12 mx-auto text-gray-600 mb-2" />
            <p className="text-sm text-gray-400">
              No LOOP minted yet. Execute profitable cycles to mint LOOP tokens.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}