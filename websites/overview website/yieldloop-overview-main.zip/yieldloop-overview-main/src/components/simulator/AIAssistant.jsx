import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, Loader2, DollarSign } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function AIAssistant({ context, data, onResult }) {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [computeCost, setComputeCost] = useState(0);

  const getPrompt = () => {
    if (context === 'strategy') {
      return `You are an expert DeFi trading advisor. Analyze this ${data.type} trading strategy configuration and provide:
1. Risk assessment (Low/Medium/High)
2. Key strengths
3. Potential risks
4. Recommended adjustments
5. Expected volatility

Configuration:
${JSON.stringify(data.config, null, 2)}

Keep response concise and actionable.`;
    } else if (context === 'risk') {
      return `You are a DeFi risk analyst. Review this trading setup:
- Total Capital: $${data.totalCapital}
- Strategies: ${data.strategies.length}
- NFT Discount: ${data.nftDiscount}%

Provide:
1. Overall risk score (1-10)
2. Diversification analysis
3. Capital allocation assessment
4. Risk mitigation suggestions`;
    } else if (context === 'referral') {
      return `Explain the YieldLoop referral program benefits for someone with ${data.referralCount} referrals and ${data.credits} credits. Be concise and practical.`;
    }
    return 'General YieldLoop platform assistance.';
  };

  const handleRequest = async () => {
    setIsLoading(true);
    const startTime = Date.now();
    
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: getPrompt(),
        add_context_from_internet: false
      });
      
      const endTime = Date.now();
      const duration = (endTime - startTime) / 1000;
      
      // Estimate compute cost (simulated)
      const estimatedCost = (duration * 0.002).toFixed(4); // $0.002 per second as example
      setComputeCost(parseFloat(estimatedCost));
      
      setResult(response);
      if (onResult) {
        onResult(response, estimatedCost);
      }
    } catch (error) {
      setResult('AI assistance unavailable. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-teal-900/20 to-blue-900/20 border-teal-800/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Sparkles className="w-5 h-5 text-teal-400" />
          AI Assistant
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!result && !isLoading && (
          <div className="text-center py-6">
            <p className="text-gray-400 text-sm mb-4">
              Get AI-powered analysis and recommendations
            </p>
            <Button
              onClick={handleRequest}
              className="bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-400 hover:to-blue-500"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Request AI Analysis
            </Button>
          </div>
        )}

        {isLoading && (
          <div className="text-center py-8">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-teal-400" />
            <p className="text-sm text-gray-400">Analyzing...</p>
          </div>
        )}

        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              <div className="p-4 rounded-lg bg-gray-900/60 border border-gray-800">
                <p className="text-sm text-gray-300 whitespace-pre-wrap">{result}</p>
              </div>
              
              <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-900/10 border border-yellow-800/30">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm text-yellow-400">Compute Cost</span>
                </div>
                <span className="text-sm font-medium text-white">${computeCost}</span>
              </div>

              <p className="text-xs text-gray-500 text-center">
                AI compute costs will be deducted from platform fees or deposits
              </p>

              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setResult(null);
                  setComputeCost(0);
                }}
                className="w-full border-gray-700"
              >
                Close
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}