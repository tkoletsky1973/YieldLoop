import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, CheckCircle2, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function NFTPurchase({ currentNFT, onPurchase, balance }) {
  const [showConfirm, setShowConfirm] = useState(false);

  const supporterNFT = {
    name: 'Supporter NFT',
    price: 300,
    discount: 5,
    benefits: [
      '5% platform fee discount',
      'Community access',
      'Early feature access',
      'Supporter badge'
    ]
  };

  const handlePurchase = () => {
    if (balance < supporterNFT.price) {
      toast.error('Insufficient balance');
      return;
    }
    onPurchase(supporterNFT);
    setShowConfirm(false);
    toast.success('Supporter NFT purchased!');
  };

  if (currentNFT) {
    return (
      <Card className="bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-800/30">
        <CardContent className="pt-6">
          <div className="text-center">
            <Shield className="w-16 h-16 mx-auto mb-4 text-purple-400" />
            <h3 className="text-xl font-medium text-white mb-2">
              {currentNFT === 'supporter' ? 'Supporter NFT' : 'Governor NFT'}
            </h3>
            <Badge className="bg-purple-600 mb-4">Active</Badge>
            <p className="text-sm text-gray-400">
              You're receiving a {currentNFT === 'supporter' ? '5' : '10'}% fee discount on all profitable cycles
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-400" />
          NFT Program
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!showConfirm ? (
          <>
            <div className="p-4 rounded-lg bg-purple-900/10 border border-purple-800/30">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="text-lg font-medium text-white mb-1">{supporterNFT.name}</h4>
                  <p className="text-2xl font-light text-purple-400">${supporterNFT.price}</p>
                </div>
                <Badge className="bg-purple-600">{supporterNFT.discount}% Discount</Badge>
              </div>
              
              <div className="space-y-2 mb-4">
                {supporterNFT.benefits.map((benefit, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm text-gray-300">
                    <CheckCircle2 className="w-4 h-4 text-purple-400" />
                    {benefit}
                  </div>
                ))}
              </div>

              <Button
                onClick={() => setShowConfirm(true)}
                className="w-full bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-400 hover:to-blue-500"
                disabled={balance < supporterNFT.price}
              >
                Purchase NFT
              </Button>
            </div>

            <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-5 h-5 text-gray-500" />
                <h4 className="text-sm font-medium text-gray-400">Governor NFT</h4>
              </div>
              <p className="text-xs text-gray-500">
                Not available for purchase. Governor NFTs are bestowed based on contribution and participation.
              </p>
            </div>
          </>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-4"
          >
            <div className="p-4 rounded-lg bg-yellow-900/10 border border-yellow-800/30">
              <p className="text-sm text-yellow-400 mb-2 font-medium">Confirm Purchase</p>
              <p className="text-xs text-gray-400 mb-3">
                You are about to purchase a Supporter NFT for ${supporterNFT.price}. This will be deducted from your vault balance.
              </p>
              <div className="text-xs text-gray-500">
                <p>• Fee discount applies immediately</p>
                <p>• NFT is non-refundable</p>
                <p>• Benefits are permanent</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => setShowConfirm(false)}
                className="border-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handlePurchase}
                className="bg-gradient-to-r from-purple-500 to-blue-600"
              >
                Confirm
              </Button>
            </div>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}