import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

const LabelText = ({ children }) => (
  <Label className="text-gray-200 font-medium">{children}</Label>
);
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Droplet, DollarSign, Sparkles } from 'lucide-react';
import AIConfirmation from './AIConfirmation';

export default function StrategyConfigurator({ onStrategyChange, onAIHelp, existingStrategies = [] }) {
  const [showAIConfirm, setShowAIConfirm] = useState(false);
  const [selectedType, setSelectedType] = useState('spot');
  const [config, setConfig] = useState({
    name: '',
    allocation: 1000,
    // Spot Trading
    tradingPair: 'ETH/USDC',
    priceRangeLow: 0,
    priceRangeHigh: 0,
    positionSize: 50,
    stopLoss: 5,
    takeProfit: 10,
    rebalanceThreshold: 2,
    // LP Vaults
    protocol: 'uniswap',
    poolType: 'ETH-USDC',
    feeLevel: 0.3,
    rangeWidth: 10,
    autoCompound: true,
    // Stablecoin
    stablePairs: ['USDC', 'DAI'],
    targetAPY: 5,
    maxSlippage: 0.5
  });

  const handleAIAutoPopulate = () => {
    setShowAIConfirm(true);
  };

  const handleAIConfirm = () => {
    setShowAIConfirm(false);
    // Auto-populate based on strategy type
    if (selectedType === 'spot') {
      setConfig({
        ...config,
        name: `AI ${config.tradingPair} Spot`,
        priceRangeLow: -15,
        priceRangeHigh: 15,
        positionSize: 60,
        stopLoss: 8,
        takeProfit: 12,
        rebalanceThreshold: 3
      });
    } else if (selectedType === 'lp') {
      setConfig({
        ...config,
        name: `AI ${config.protocol} LP`,
        rangeWidth: 15,
        autoCompound: true
      });
    } else if (selectedType === 'stable') {
      setConfig({
        ...config,
        name: 'AI Stablecoin Yield',
        targetAPY: 8,
        maxSlippage: 0.3,
        stablePairs: ['USDC', 'DAI', 'USDT']
      });
    }
    onAIHelp('strategy', selectedType, config);
  };

  const handleSubmit = () => {
    if (!config.name) {
      alert('Please enter a strategy name');
      return;
    }
    onStrategyChange({ ...config, type: selectedType });
    // Reset form
    setConfig({ ...config, name: '', allocation: 1000 });
  };

  return (
    <>
      {showAIConfirm && (
        <AIConfirmation
          strategyType={selectedType}
          onConfirm={handleAIConfirm}
          onCancel={() => setShowAIConfirm(false)}
        />
      )}
      
      <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Configure Strategy</span>
            <Button
              variant="outline"
              size="sm"
              onClick={handleAIAutoPopulate}
              className="border-teal-500/30 hover:bg-teal-500/10"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              AI Auto-Fill
            </Button>
          </CardTitle>
        </CardHeader>
      <CardContent className="space-y-4">
        {/* Strategy Type Selection */}
        <div>
          <Label>Strategy Type</Label>
          <div className="grid grid-cols-3 gap-3 mt-2">
            <Button
              variant={selectedType === 'spot' ? 'default' : 'outline'}
              onClick={() => setSelectedType('spot')}
              className={selectedType === 'spot' ? 'bg-purple-600' : ''}
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              Spot
            </Button>
            <Button
              variant={selectedType === 'lp' ? 'default' : 'outline'}
              onClick={() => setSelectedType('lp')}
              className={selectedType === 'lp' ? 'bg-blue-600' : ''}
            >
              <Droplet className="w-4 h-4 mr-2" />
              LP Vaults
            </Button>
            <Button
              variant={selectedType === 'stable' ? 'default' : 'outline'}
              onClick={() => setSelectedType('stable')}
              className={selectedType === 'stable' ? 'bg-green-600' : ''}
            >
              <DollarSign className="w-4 h-4 mr-2" />
              Stablecoin
            </Button>
          </div>
        </div>

        {/* Strategy Name */}
        <div>
          <LabelText>Strategy Name</LabelText>
          <Input
            value={config.name}
            onChange={(e) => setConfig({ ...config, name: e.target.value })}
            placeholder="My Strategy"
            className="bg-gray-800 border-gray-600 text-white placeholder:text-gray-500 text-base"
          />
        </div>

        {/* Capital Allocation */}
        <div>
          <LabelText>Capital Allocation (USD)</LabelText>
          <Input
            type="number"
            value={config.allocation}
            onChange={(e) => setConfig({ ...config, allocation: Number(e.target.value) })}
            min={100}
            step={100}
            className="bg-gray-800 border-gray-600 text-white text-base"
          />
        </div>

        {/* Spot Trading Configuration */}
        {selectedType === 'spot' && (
          <div className="space-y-4 p-4 rounded-lg bg-purple-900/20 border border-purple-700/50">
            <h4 className="text-base font-semibold text-purple-300">Spot Trading Parameters</h4>
            
            <div>
              <LabelText>Trading Pair</LabelText>
              <Select value={config.tradingPair} onValueChange={(val) => setConfig({ ...config, tradingPair: val })}>
                <SelectTrigger className="bg-gray-800/50 border-gray-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ETH/USDC">ETH/USDC</SelectItem>
                  <SelectItem value="BTC/USDC">BTC/USDC</SelectItem>
                  <SelectItem value="SOL/USDC">SOL/USDC</SelectItem>
                  <SelectItem value="AVAX/USDC">AVAX/USDC</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <LabelText>Price Range Low (%)</LabelText>
                <Input
                  type="number"
                  value={config.priceRangeLow}
                  onChange={(e) => setConfig({ ...config, priceRangeLow: Number(e.target.value) })}
                  className="bg-gray-800 border-gray-600 text-white text-base"
                />
              </div>
              <div>
                <LabelText>Price Range High (%)</LabelText>
                <Input
                  type="number"
                  value={config.priceRangeHigh}
                  onChange={(e) => setConfig({ ...config, priceRangeHigh: Number(e.target.value) })}
                  className="bg-gray-800 border-gray-600 text-white text-base"
                />
              </div>
            </div>

            <div>
              <LabelText>Position Size (% of allocation)</LabelText>
              <Slider
                value={[config.positionSize]}
                onValueChange={(val) => setConfig({ ...config, positionSize: val[0] })}
                min={10}
                max={100}
                step={5}
                className="my-3"
              />
              <span className="text-sm text-gray-300 font-medium">{config.positionSize}%</span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <LabelText>Stop Loss (%)</LabelText>
                <Input
                  type="number"
                  value={config.stopLoss}
                  onChange={(e) => setConfig({ ...config, stopLoss: Number(e.target.value) })}
                  step={0.5}
                  className="bg-gray-800 border-gray-600 text-white text-base"
                />
              </div>
              <div>
                <LabelText>Take Profit (%)</LabelText>
                <Input
                  type="number"
                  value={config.takeProfit}
                  onChange={(e) => setConfig({ ...config, takeProfit: Number(e.target.value) })}
                  step={0.5}
                  className="bg-gray-800 border-gray-600 text-white text-base"
                />
              </div>
            </div>

            <div>
              <LabelText>Rebalance Threshold (%)</LabelText>
              <Input
                type="number"
                value={config.rebalanceThreshold}
                onChange={(e) => setConfig({ ...config, rebalanceThreshold: Number(e.target.value) })}
                step={0.5}
                className="bg-gray-800 border-gray-600 text-white text-base"
              />
            </div>
          </div>
        )}

        {/* LP Vaults Configuration */}
        {selectedType === 'lp' && (
          <div className="space-y-4 p-4 rounded-lg bg-blue-900/20 border border-blue-700/50">
            <h4 className="text-base font-semibold text-blue-300">LP Vault Parameters</h4>
            
            <div>
              <LabelText>Protocol</LabelText>
              <Select value={config.protocol} onValueChange={(val) => setConfig({ ...config, protocol: val })}>
                <SelectTrigger className="bg-gray-800/50 border-gray-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="uniswap">Uniswap V3</SelectItem>
                  <SelectItem value="curve">Curve</SelectItem>
                  <SelectItem value="balancer">Balancer</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <LabelText>Pool Type</LabelText>
              <Select value={config.poolType} onValueChange={(val) => setConfig({ ...config, poolType: val })}>
                <SelectTrigger className="bg-gray-800/50 border-gray-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ETH-USDC">ETH-USDC</SelectItem>
                  <SelectItem value="BTC-ETH">BTC-ETH</SelectItem>
                  <SelectItem value="stables">USDC-DAI-USDT</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <LabelText>Fee Tier (%)</LabelText>
              <Select value={config.feeLevel.toString()} onValueChange={(val) => setConfig({ ...config, feeLevel: Number(val) })}>
                <SelectTrigger className="bg-gray-800/50 border-gray-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0.01">0.01%</SelectItem>
                  <SelectItem value="0.05">0.05%</SelectItem>
                  <SelectItem value="0.3">0.3%</SelectItem>
                  <SelectItem value="1">1%</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <LabelText>Range Width (% from current price)</LabelText>
              <Slider
                value={[config.rangeWidth]}
                onValueChange={(val) => setConfig({ ...config, rangeWidth: val[0] })}
                min={2}
                max={50}
                step={2}
                className="my-3"
              />
              <span className="text-sm text-gray-300 font-medium">±{config.rangeWidth}%</span>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={config.autoCompound}
                onChange={(e) => setConfig({ ...config, autoCompound: e.target.checked })}
                className="rounded"
              />
              <LabelText>Auto-compound rewards</LabelText>
            </div>
          </div>
        )}

        {/* Stablecoin Configuration */}
        {selectedType === 'stable' && (
          <div className="space-y-4 p-4 rounded-lg bg-green-900/20 border border-green-700/50">
            <h4 className="text-base font-semibold text-green-300">Stablecoin Yield Parameters</h4>
            
            <div>
              <LabelText>Target Stablecoins</LabelText>
              <div className="flex gap-2 flex-wrap mt-2">
                {['USDC', 'DAI', 'USDT', 'FRAX'].map(coin => (
                  <Badge
                    key={coin}
                    variant={config.stablePairs.includes(coin) ? 'default' : 'outline'}
                    className="cursor-pointer"
                    onClick={() => {
                      const newPairs = config.stablePairs.includes(coin)
                        ? config.stablePairs.filter(c => c !== coin)
                        : [...config.stablePairs, coin];
                      setConfig({ ...config, stablePairs: newPairs });
                    }}
                  >
                    {coin}
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <LabelText>Target APY (%)</LabelText>
              <Input
                type="number"
                value={config.targetAPY}
                onChange={(e) => setConfig({ ...config, targetAPY: Number(e.target.value) })}
                step={0.5}
                min={1}
                max={20}
                className="bg-gray-800 border-gray-600 text-white text-base"
              />
              <p className="text-xs text-gray-300 mt-1">Seeking yields from Aave, Compound, Curve stablecoin pools</p>
            </div>

            <div>
              <LabelText>Max Slippage (%)</LabelText>
              <Input
                type="number"
                value={config.maxSlippage}
                onChange={(e) => setConfig({ ...config, maxSlippage: Number(e.target.value) })}
                step={0.1}
                min={0.1}
                max={2}
                className="bg-gray-800 border-gray-600 text-white text-base"
              />
            </div>
          </div>
        )}

        <Button 
          onClick={handleSubmit}
          className="w-full bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-400 hover:to-blue-500"
        >
          Add Strategy
        </Button>

        {/* Active Strategies */}
        {existingStrategies.length > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-700">
            <LabelText className="mb-2 block">Active Strategies</LabelText>
            <div className="space-y-2">
              {existingStrategies.map((strat, idx) => (
                <div key={idx} className="p-3 rounded-lg bg-gray-800/50 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-white">{strat.name}</span>
                    <Badge variant="outline">${strat.allocation}</Badge>
                  </div>
                  <div className="text-xs text-gray-400 mt-1">
                    {strat.type === 'spot' && `${strat.tradingPair} - ${strat.positionSize}% position`}
                    {strat.type === 'lp' && `${strat.protocol} - ${strat.poolType}`}
                    {strat.type === 'stable' && `${strat.stablePairs.join('/')} - ${strat.targetAPY}% APY`}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
    </>
  );
}