import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, Play, Clock, BarChart3 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function BacktestingPanel({ strategies, onBacktestComplete }) {
  const [period, setPeriod] = React.useState('30');
  const [isRunning, setIsRunning] = React.useState(false);
  const [results, setResults] = React.useState(null);

  const runBacktest = async () => {
    if (strategies.length === 0) {
      alert('Add at least one strategy before backtesting');
      return;
    }

    setIsRunning(true);
    await new Promise(resolve => setTimeout(resolve, 2000));

    const cycles = parseInt(period);
    const backtestData = [];
    let currentBalance = strategies.reduce((sum, s) => sum + s.allocation, 0);
    let totalLoopMinted = 0;

    for (let i = 0; i < cycles; i++) {
      let cycleProfit = 0;
      let cycleLoop = 0;

      strategies.forEach(strategy => {
        const successRate = strategy.type === 'stable' ? 85 : strategy.type === 'lp' ? 70 : 60;
        const isProfit = Math.random() * 100 < successRate;
        
        const baseReturn = strategy.type === 'stable' ? 1.5 : strategy.type === 'lp' ? 3 : 5;
        const returnPercent = isProfit 
          ? (Math.random() * baseReturn) + 0.5
          : -(Math.random() * (baseReturn / 2)) - 0.3;
        
        const profit = strategy.allocation * (returnPercent / 100);
        cycleProfit += profit;
        
        if (isProfit) {
          cycleLoop += Math.abs(profit) * 0.1;
        }
      });

      currentBalance += cycleProfit;
      totalLoopMinted += cycleLoop;

      backtestData.push({
        cycle: i + 1,
        balance: parseFloat(currentBalance.toFixed(2)),
        profit: parseFloat(cycleProfit.toFixed(2)),
        loopMinted: parseFloat(cycleLoop.toFixed(2)),
        cumulativeProfit: parseFloat((currentBalance - strategies.reduce((sum, s) => sum + s.allocation, 0)).toFixed(2))
      });
    }

    const startBalance = strategies.reduce((sum, s) => sum + s.allocation, 0);
    const finalBalance = currentBalance;
    const totalProfit = finalBalance - startBalance;
    const profitableCycles = backtestData.filter(d => d.profit > 0).length;
    const avgProfit = backtestData.reduce((sum, d) => sum + d.profit, 0) / cycles;

    setResults({
      data: backtestData,
      summary: {
        startBalance,
        finalBalance,
        totalProfit,
        totalLoopMinted,
        profitableCycles,
        totalCycles: cycles,
        winRate: ((profitableCycles / cycles) * 100).toFixed(1),
        avgProfit: avgProfit.toFixed(2),
        roi: ((totalProfit / startBalance) * 100).toFixed(2)
      }
    });

    setIsRunning(false);
    
    if (onBacktestComplete) {
      onBacktestComplete(results);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-indigo-900/20 to-purple-900/20 border-indigo-700/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <BarChart3 className="w-5 h-5 text-indigo-400" />
          Backtesting
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <label className="text-base text-gray-200 font-medium mb-2 block">
              <Clock className="w-4 h-4 inline mr-1" />
              Simulation Period
            </label>
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10 Cycles (Short)</SelectItem>
                <SelectItem value="30">30 Cycles (1 Month)</SelectItem>
                <SelectItem value="90">90 Cycles (3 Months)</SelectItem>
                <SelectItem value="180">180 Cycles (6 Months)</SelectItem>
                <SelectItem value="365">365 Cycles (1 Year)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={runBacktest}
            disabled={isRunning || strategies.length === 0}
            className="mt-8 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500"
          >
            {isRunning ? (
              <>Running...</>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Run Backtest
              </>
            )}
          </Button>
        </div>

        {results && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Summary Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50">
                <p className="text-xs text-gray-400 mb-1">Total Profit</p>
                <p className={`text-xl font-semibold ${results.summary.totalProfit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  ${results.summary.totalProfit.toFixed(2)}
                </p>
              </div>
              <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50">
                <p className="text-xs text-gray-400 mb-1">Win Rate</p>
                <p className="text-xl font-semibold text-white">{results.summary.winRate}%</p>
              </div>
              <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50">
                <p className="text-xs text-gray-400 mb-1">ROI</p>
                <p className={`text-xl font-semibold ${results.summary.roi >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {results.summary.roi}%
                </p>
              </div>
              <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50">
                <p className="text-xs text-gray-400 mb-1">LOOP Minted</p>
                <p className="text-xl font-semibold text-teal-400">{results.summary.totalLoopMinted.toFixed(2)}</p>
              </div>
            </div>

            {/* Performance Chart */}
            <div className="p-4 rounded-lg bg-gray-900/50 border border-gray-800/50">
              <h4 className="text-sm font-medium text-gray-200 mb-4">Balance Over Time</h4>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={results.data}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="cycle" 
                    stroke="#9CA3AF"
                    tick={{ fill: '#9CA3AF' }}
                    label={{ value: 'Cycle', position: 'insideBottom', offset: -5, fill: '#9CA3AF' }}
                  />
                  <YAxis 
                    stroke="#9CA3AF"
                    tick={{ fill: '#9CA3AF' }}
                    label={{ value: 'Balance ($)', angle: -90, position: 'insideLeft', fill: '#9CA3AF' }}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
                    labelStyle={{ color: '#F3F4F6' }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="balance" 
                    stroke="#14B8A6" 
                    strokeWidth={2}
                    dot={false}
                    name="Balance"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="cumulativeProfit" 
                    stroke="#8B5CF6" 
                    strokeWidth={2}
                    dot={false}
                    name="Cumulative Profit"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Detailed Stats */}
            <div className="p-4 rounded-lg bg-gray-800/30 border border-gray-700/50">
              <h4 className="text-sm font-medium text-gray-200 mb-3">Backtest Summary</h4>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-400">Starting Balance:</span>
                  <span className="text-white ml-2">${results.summary.startBalance.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-gray-400">Final Balance:</span>
                  <span className="text-white ml-2">${results.summary.finalBalance.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-gray-400">Profitable Cycles:</span>
                  <span className="text-white ml-2">{results.summary.profitableCycles}/{results.summary.totalCycles}</span>
                </div>
                <div>
                  <span className="text-gray-400">Avg Profit/Cycle:</span>
                  <span className={`ml-2 ${parseFloat(results.summary.avgProfit) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    ${results.summary.avgProfit}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {!results && (
          <div className="text-center py-8">
            <TrendingUp className="w-12 h-12 mx-auto text-gray-600 mb-3" />
            <p className="text-gray-400 text-sm">
              Configure your strategies above, then run a backtest to see historical performance simulation.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}