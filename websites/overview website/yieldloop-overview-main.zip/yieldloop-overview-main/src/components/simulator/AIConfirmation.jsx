import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, DollarSign, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AIConfirmation({ strategyType, onConfirm, onCancel }) {
  const estimatedCost = 0.05; // Estimated cost per AI request
  const isFree = false; // Set to true if using free AI service

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-6"
    >
      <Card className="bg-gray-900 border-gray-800 max-w-lg w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-teal-400" />
            AI Strategy Auto-Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 rounded-lg bg-teal-900/10 border border-teal-800/30">
            <p className="text-sm text-teal-400 mb-2 font-medium">What AI Will Do</p>
            <p className="text-xs text-gray-400 leading-relaxed">
              The AI will analyze your {strategyType} strategy requirements and automatically populate all configuration fields with optimized parameters based on current market conditions and risk profiles.
            </p>
          </div>

          {!isFree && (
            <div className="p-4 rounded-lg bg-yellow-900/10 border border-yellow-800/30">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm text-yellow-400 font-medium">AI Compute Cost</span>
                </div>
                <span className="text-sm font-medium text-white">${estimatedCost.toFixed(3)}</span>
              </div>
              <p className="text-xs text-gray-400">
                This cost will be deducted from your platform fees or at deposit. AI costs help maintain the service.
              </p>
            </div>
          )}

          {isFree && (
            <div className="p-4 rounded-lg bg-green-900/10 border border-green-800/30">
              <p className="text-sm text-green-400 font-medium">✓ Free AI Service</p>
              <p className="text-xs text-gray-400 mt-1">
                No additional costs for AI assistance during preview period
              </p>
            </div>
          )}

          <div className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-gray-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-gray-400 leading-relaxed">
                You can review and modify all AI-suggested parameters before finalizing your strategy. AI recommendations are guidance only.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-2">
            <Button
              variant="outline"
              onClick={onCancel}
              className="border-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={onConfirm}
              className="bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-400 hover:to-blue-500"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Confirm & Generate
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}