import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

export default function CycleHistory({ history }) {
  const exportToCSV = () => {
    if (history.length === 0) {
      toast.error('No cycle history to export');
      return;
    }

    const headers = ['Cycle', 'Strategy', 'Start Balance', 'End Balance', 'Profit/Loss', 'LOOP Minted', 'Timestamp'];
    const rows = history.map(cycle => [
      cycle.cycleNumber,
      cycle.strategyName,
      cycle.startBalance.toFixed(2),
      cycle.endBalance.toFixed(2),
      cycle.profit.toFixed(2),
      cycle.loopMinted.toFixed(2),
      new Date(cycle.timestamp).toLocaleString()
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `yieldloop_cycles_${Date.now()}.csv`;
    link.click();
    
    toast.success('Cycle history exported!');
  };

  const exportToJSON = () => {
    if (history.length === 0) {
      toast.error('No cycle history to export');
      return;
    }

    const jsonContent = JSON.stringify(history, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `yieldloop_cycles_${Date.now()}.json`;
    link.click();
    
    toast.success('Cycle history exported!');
  };

  return (
    <Card className="bg-gradient-to-br from-gray-900/80 to-gray-900/40 border-gray-800/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-teal-400" />
            Cycle History
          </CardTitle>
          {history.length > 0 && (
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={exportToCSV}
                className="border-gray-700"
              >
                <Download className="w-4 h-4 mr-2" />
                CSV
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={exportToJSON}
                className="border-gray-700"
              >
                <Download className="w-4 h-4 mr-2" />
                JSON
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {history.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 mx-auto mb-4 text-gray-600" />
            <p className="text-gray-400">No cycles executed yet</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            <AnimatePresence>
              {history.map((cycle, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className={`p-4 rounded-lg border ${
                    cycle.profit > 0
                      ? 'bg-green-900/10 border-green-800/30'
                      : 'bg-red-900/10 border-red-800/30'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {cycle.profit > 0 ? (
                        <CheckCircle2 className="w-4 h-4 text-green-400" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-red-400" />
                      )}
                      <span className="font-medium text-white">Cycle #{cycle.cycleNumber}</span>
                    </div>
                    <span className={`text-sm font-medium ${cycle.profit > 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {cycle.profit > 0 ? '+' : ''}{cycle.profit.toFixed(2)} USD
                    </span>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-xs">
                      <div>
                        <p className="text-gray-500">Strategy</p>
                        <p className="text-white truncate">{cycle.strategyName}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Start</p>
                        <p className="text-white">${cycle.startBalance.toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">End</p>
                        <p className="text-white">${cycle.endBalance.toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">LOOP</p>
                        <p className="text-teal-400">{cycle.loopMinted.toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Time</p>
                        <p className="text-white">{new Date(cycle.timestamp).toLocaleDateString()}</p>
                      </div>
                    </div>
                    {cycle.details && cycle.details.length > 0 && (
                      <div className="pt-2 border-t border-gray-800/50">
                        {cycle.details.map((detail, idx) => (
                          <p key={idx} className="text-xs text-gray-400">
                            • {detail.strategyName}: {detail.details}
                          </p>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </CardContent>
    </Card>
  );
}