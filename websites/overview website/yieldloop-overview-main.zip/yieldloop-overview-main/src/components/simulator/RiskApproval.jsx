import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, FileText, CheckSquare } from 'lucide-react';
import { motion } from 'framer-motion';

export default function RiskApproval({ strategies, onApprove, onCancel }) {
  const [acceptedRisks, setAcceptedRisks] = useState({
    lossOfFunds: false,
    noGuarantees: false,
    marketVolatility: false,
    platformRisks: false,
    taxObligations: false
  });

  const allAccepted = Object.values(acceptedRisks).every(v => v);

  const riskDisclosures = [
    {
      key: 'lossOfFunds',
      title: 'Risk of Total Loss',
      text: 'You may lose some or all of your deposited funds. Past performance does not predict future results.'
    },
    {
      key: 'noGuarantees',
      title: 'No Guarantees',
      text: 'There are no guaranteed returns. LOOP token has no promised value. All strategies can fail.'
    },
    {
      key: 'marketVolatility',
      title: 'Market Volatility',
      text: 'Cryptocurrency markets are highly volatile. Prices can change rapidly and unpredictably.'
    },
    {
      key: 'platformRisks',
      title: 'Platform Risks',
      text: 'Smart contract bugs, protocol exploits, and technical failures are possible despite testing.'
    },
    {
      key: 'taxObligations',
      title: 'Tax Obligations',
      text: 'You are responsible for all tax reporting and compliance in your jurisdiction.'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-6"
    >
      <Card className="bg-gray-900 border-gray-800 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <AlertTriangle className="w-6 h-6 text-yellow-400" />
            Risk Acknowledgment Required
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Strategy Summary */}
          <div className="p-4 rounded-lg bg-blue-900/10 border border-blue-800/30">
            <p className="text-sm text-blue-400 mb-3 font-medium">Strategy Configuration Summary</p>
            <div className="space-y-2">
              {strategies.map((strat, idx) => (
                <div key={idx} className="text-sm text-gray-300">
                  <span className="font-medium">{strat.name}</span>: ${strat.allocation} ({strat.type})
                </div>
              ))}
              <div className="pt-2 border-t border-gray-800 mt-2">
                <span className="text-white font-medium">
                  Total Allocation: ${strategies.reduce((sum, s) => sum + s.allocation, 0)}
                </span>
              </div>
            </div>
          </div>

          {/* Risk Disclosures */}
          <div className="space-y-3">
            <p className="text-sm text-gray-400 font-medium flex items-center gap-2">
              <FileText className="w-4 h-4" />
              You must acknowledge all risks below
            </p>
            
            {riskDisclosures.map((risk) => (
              <div
                key={risk.key}
                className="p-4 rounded-lg bg-yellow-900/10 border border-yellow-800/30"
              >
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={acceptedRisks[risk.key]}
                    onChange={(e) => setAcceptedRisks({
                      ...acceptedRisks,
                      [risk.key]: e.target.checked
                    })}
                    className="mt-1 rounded"
                  />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-yellow-400 mb-1">{risk.title}</p>
                    <p className="text-xs text-gray-400">{risk.text}</p>
                  </div>
                </label>
              </div>
            ))}
          </div>

          {/* Final Confirmation */}
          <div className="p-4 rounded-lg bg-red-900/10 border border-red-800/30">
            <p className="text-sm text-red-400 font-medium mb-2">Final Confirmation</p>
            <p className="text-xs text-gray-400 leading-relaxed">
              By clicking "I Understand and Accept", you acknowledge that you have read, understood, and accept 
              all risks. You confirm that you are making an informed decision with capital you can afford to lose. 
              This is a simulation, but real trading carries these exact risks.
            </p>
          </div>

          {/* Actions */}
          <div className="grid grid-cols-2 gap-4">
            <Button
              variant="outline"
              onClick={onCancel}
              className="border-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={onApprove}
              disabled={!allAccepted}
              className="bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <CheckSquare className="w-4 h-4 mr-2" />
              I Understand and Accept
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}