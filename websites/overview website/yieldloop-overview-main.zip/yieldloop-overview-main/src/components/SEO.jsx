import { useEffect } from 'react';

export default function SEO({ title, description, keywords, canonical }) {
  useEffect(() => {
    // Set page title
    document.title = title ? `${title} | YieldLoop` : 'YieldLoop - Cycle-based Trading Platform';

    // Set or update meta description
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.name = 'description';
      document.head.appendChild(metaDescription);
    }
    metaDescription.content = description || 'A system that doesn\'t lie about whether it worked. Cycle-based trading with verified profit only.';

    // Set or update meta keywords
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.name = 'keywords';
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.content = keywords || 'DeFi, yield, trading, cryptocurrency, non-custodial, blockchain';

    // Set or update canonical URL
    let linkCanonical = document.querySelector('link[rel="canonical"]');
    if (!linkCanonical) {
      linkCanonical = document.createElement('link');
      linkCanonical.rel = 'canonical';
      document.head.appendChild(linkCanonical);
    }
    linkCanonical.href = canonical || window.location.href;

    // Open Graph tags
    const ogTags = [
      { property: 'og:title', content: title || 'YieldLoop' },
      { property: 'og:description', content: description || 'A system that doesn\'t lie about whether it worked.' },
      { property: 'og:type', content: 'website' },
      { property: 'og:url', content: canonical || window.location.href },
      { property: 'og:image', content: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_6941e4c2f08b371ab7b96903/7255a49e0_F0B395C3-0C49-4C59-AD35-9BF5BC3203A8.png' }
    ];

    ogTags.forEach(({ property, content }) => {
      let ogTag = document.querySelector(`meta[property="${property}"]`);
      if (!ogTag) {
        ogTag = document.createElement('meta');
        ogTag.setAttribute('property', property);
        document.head.appendChild(ogTag);
      }
      ogTag.content = content;
    });

    // Twitter Card tags
    const twitterTags = [
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: title || 'YieldLoop' },
      { name: 'twitter:description', content: description || 'A system that doesn\'t lie about whether it worked.' },
      { name: 'twitter:image', content: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_6941e4c2f08b371ab7b96903/7255a49e0_F0B395C3-0C49-4C59-AD35-9BF5BC3203A8.png' }
    ];

    twitterTags.forEach(({ name, content }) => {
      let twitterTag = document.querySelector(`meta[name="${name}"]`);
      if (!twitterTag) {
        twitterTag = document.createElement('meta');
        twitterTag.name = name;
        document.head.appendChild(twitterTag);
      }
      twitterTag.content = content;
    });
  }, [title, description, keywords, canonical]);

  return null;
}