import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import Navigation from '@/components/landing/Navigation';
import Footer from '@/components/landing/Footer';
import SEO from '@/components/SEO';
import StrategyConfigurator from '@/components/simulator/StrategyConfigurator';
import AIAssistant from '@/components/simulator/AIAssistant';
import NFTPurchase from '@/components/simulator/NFTPurchase';
import ReferralDashboard from '@/components/simulator/ReferralDashboard';
import CycleHistory from '@/components/simulator/CycleHistory';
import RiskApproval from '@/components/simulator/RiskApproval';
import BacktestingPanel from '@/components/simulator/BacktestingPanel';
import LoopEconomics from '@/components/simulator/LoopEconomics';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  TrendingUp, 
  TrendingDown, 
  Play, 
  Wallet,
  Coins,
  Activity,
  Sparkles,
  Settings,
  AlertCircle
} from 'lucide-react';
import toast from 'react-hot-toast';

export default function Simulator() {
  const [user, setUser] = useState(null);
  const [simulatorState, setSimulatorState] = useState({
    balance: 0,
    loopBalance: 0,
    cyclesCompleted: 0,
    totalProfit: 0,
    totalLoss: 0,
    strategies: [],
    nft: null,
    referrals: { count: 0, credits: 0 },
    history: [],
    aiCosts: 0
  });
  const [depositAmount, setDepositAmount] = useState(1000);
  const [isRunning, setIsRunning] = useState(false);
  const [showRiskApproval, setShowRiskApproval] = useState(false);
  const [pendingStrategies, setPendingStrategies] = useState([]);
  const [showAI, setShowAI] = useState(false);
  const [aiContext, setAIContext] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      // Load saved simulator state with defaults
      if (currentUser.simulator_state) {
        const saved = currentUser.simulator_state;
        setSimulatorState({
          balance: saved.balance || 0,
          loopBalance: saved.loopBalance || 0,
          cyclesCompleted: saved.cyclesCompleted || 0,
          totalProfit: saved.totalProfit || 0,
          totalLoss: saved.totalLoss || 0,
          strategies: saved.strategies || [],
          nft: saved.nft || null,
          referrals: saved.referrals || { count: 0, credits: 0 },
          history: saved.history || [],
          aiCosts: saved.aiCosts || 0
        });
      }
    } catch (error) {
      console.log('User not logged in');
    }
  };

  const saveState = async (newState) => {
    setSimulatorState(newState);
    if (user) {
      await base44.auth.updateMe({ simulator_state: newState });
    }
  };

  const handleDeposit = async () => {
    if (depositAmount < 100) {
      toast.error('Minimum deposit is $100');
      return;
    }
    
    const newState = {
      ...simulatorState,
      balance: simulatorState.balance + depositAmount
    };
    await saveState(newState);
    toast.success(`Deposited $${depositAmount.toLocaleString()}`);
    setDepositAmount(1000);
  };

  const handleStrategyAdd = (strategy) => {
    if (strategy.allocation > simulatorState.balance) {
      toast.error('Insufficient balance for this allocation');
      return;
    }
    
    const newStrategies = [...simulatorState.strategies, strategy];
    setPendingStrategies(newStrategies);
    setShowRiskApproval(true);
  };

  const handleRiskApproval = async () => {
    const newState = {
      ...simulatorState,
      strategies: pendingStrategies
    };
    await saveState(newState);
    setShowRiskApproval(false);
    setPendingStrategies([]);
    toast.success('Strategies configured and approved!');
  };

  const handleNFTPurchase = async (nft) => {
    const newState = {
      ...simulatorState,
      balance: simulatorState.balance - nft.price,
      nft: 'supporter'
    };
    await saveState(newState);
  };

  const handleAIHelp = (context, type, data) => {
    setAIContext({ context, type, data });
    setShowAI(true);
  };

  const handleAIResult = async (result, cost) => {
    const newState = {
      ...simulatorState,
      aiCosts: simulatorState.aiCosts + parseFloat(cost)
    };
    await saveState(newState);
  };

  const runCycle = async () => {
    if (simulatorState.strategies.length === 0) {
      toast.error('Configure at least one strategy first');
      return;
    }

    setIsRunning(true);
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Execute cycles for each strategy
    const cycleResults = [];
    let totalProfit = 0;
    let totalLoopMinted = 0;

    for (const strategy of simulatorState.strategies) {
      const successRate = strategy.type === 'stable' ? 85 : strategy.type === 'lp' ? 70 : 60;
      const isProfit = Math.random() * 100 < successRate;
      
      const baseReturn = strategy.type === 'stable' ? 1.5 : strategy.type === 'lp' ? 3 : 5;
      const returnPercent = isProfit 
        ? (Math.random() * baseReturn) + 0.5
        : -(Math.random() * (baseReturn / 2)) - 0.3;
      
      const profit = strategy.allocation * (returnPercent / 100);
      totalProfit += profit;

      // Apply NFT discount to fees
      const feeRate = simulatorState.nft === 'supporter' ? 0.95 : 1; // 5% discount
      const loopMinted = isProfit ? Math.abs(profit) * 0.1 * feeRate : 0;
      totalLoopMinted += loopMinted;

      let executionDetails = '';
      if (strategy.type === 'stable') {
        const protocols = ['Aave USDC', 'Compound DAI', 'Curve 3pool'];
        const randomProtocol = protocols[Math.floor(Math.random() * protocols.length)];
        const currentAPY = (strategy.targetAPY + (Math.random() * 2 - 1)).toFixed(2);
        executionDetails = `Staked in ${randomProtocol}, Current APY: ${currentAPY}%`;
      } else if (strategy.type === 'lp') {
        executionDetails = `${strategy.protocol} ${strategy.poolType} - Fee Tier: ${strategy.feeLevel}%`;
      } else {
        executionDetails = `${strategy.tradingPair} - Position: ${strategy.positionSize}%`;
      }

      cycleResults.push({
        strategyName: strategy.name,
        profit,
        loopMinted,
        details: executionDetails
      });
    }

    const newBalance = simulatorState.balance + totalProfit;
    
    const cycleRecord = {
      cycleNumber: simulatorState.cyclesCompleted + 1,
      startBalance: simulatorState.balance,
      endBalance: newBalance,
      profit: totalProfit,
      loopMinted: totalLoopMinted,
      timestamp: new Date().toISOString(),
      strategyName: `${simulatorState.strategies.length} strategies`,
      details: cycleResults
    };

    const newState = {
      ...simulatorState,
      balance: newBalance,
      loopBalance: simulatorState.loopBalance + totalLoopMinted,
      cyclesCompleted: simulatorState.cyclesCompleted + 1,
      totalProfit: totalProfit > 0 ? simulatorState.totalProfit + totalProfit : simulatorState.totalProfit,
      totalLoss: totalProfit < 0 ? simulatorState.totalLoss + Math.abs(totalProfit) : simulatorState.totalLoss,
      history: [cycleRecord, ...simulatorState.history]
    };

    await saveState(newState);
    setIsRunning(false);
    
    if (totalProfit > 0) {
      toast.success(`Cycle completed! Profit: $${totalProfit.toFixed(2)}`);
    } else {
      toast.error(`Cycle completed. Loss: $${Math.abs(totalProfit).toFixed(2)}`);
    }
  };

  const resetSimulator = async () => {
    const newState = {
      balance: 0,
      loopBalance: 0,
      cyclesCompleted: 0,
      totalProfit: 0,
      totalLoss: 0,
      strategies: [],
      nft: null,
      referrals: { count: 0, credits: 0 },
      history: [],
      aiCosts: 0
    };
    await saveState(newState);
    toast.success('Simulator reset');
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0a0f1a] text-white">
        <SEO 
          title="Interactive Simulator"
          description="Experience YieldLoop's cycle-based trading system with our interactive simulator. Test strategies and understand the platform before launch."
          keywords="YieldLoop simulator, DeFi demo, trading simulation, cycle-based trading demo"
        />
        <Navigation currentPage="Simulator" />
        <main className="pt-32 pb-20 px-6">
          <div className="max-w-2xl mx-auto text-center">
            <Sparkles className="w-16 h-16 mx-auto mb-6 text-teal-400" />
            <h1 className="text-4xl font-light text-white mb-4">Interactive Simulator</h1>
            <p className="text-gray-400 mb-8">
              Please log in to access your personalized simulator experience.
            </p>
            <Button 
              onClick={() => base44.auth.redirectToLogin()}
              className="bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-400 hover:to-blue-500"
            >
              Log In to Start
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white">
      <SEO 
        title="Interactive Simulator"
        description="Experience YieldLoop's cycle-based trading system with our interactive simulator. Test strategies and understand the platform before launch."
        keywords="YieldLoop simulator, DeFi demo, trading simulation, cycle-based trading demo"
      />
      <Navigation currentPage="Simulator" />
      
      <main className="pt-32 pb-20 px-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="flex items-center justify-center gap-3 mb-4">
              <Sparkles className="w-8 h-8 text-teal-400" />
              <h1 className="text-4xl md:text-5xl font-light">
                Interactive <span className="bg-gradient-to-r from-teal-400 to-blue-500 bg-clip-text text-transparent">Simulator</span>
              </h1>
            </div>
            <div className="flex items-center justify-center gap-4 mb-4">
              <p className="text-gray-400 font-light">
                Experience YieldLoop's cycle-based system
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={resetSimulator}
                className="border-red-700 hover:bg-red-900/20 text-red-400"
              >
                Reset Simulator
              </Button>
            </div>
          </motion.div>

          {/* Risk Approval Modal */}
          {showRiskApproval && (
            <RiskApproval
              strategies={pendingStrategies}
              onApprove={handleRiskApproval}
              onCancel={() => {
                setShowRiskApproval(false);
                setPendingStrategies([]);
              }}
            />
          )}

          <div className="grid lg:grid-cols-4 gap-6 mb-8">
            {/* Balance Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg text-white">
                    <Wallet className="w-5 h-5 text-teal-400" />
                    Vault Balance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-light text-white">${simulatorState.balance.toFixed(2)}</p>
                  <p className="text-sm text-gray-500 mt-1">Available for trading</p>
                </CardContent>
              </Card>
            </motion.div>

            {/* LOOP Balance Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg text-white">
                    <Coins className="w-5 h-5 text-blue-400" />
                    LOOP Tokens
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-light text-white">{simulatorState.loopBalance.toFixed(2)}</p>
                  <p className="text-sm text-gray-500 mt-1">Minted from profits</p>
                </CardContent>
              </Card>
            </motion.div>

            {/* Cycles Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg text-white">
                    <Activity className="w-5 h-5 text-purple-400" />
                    Cycles
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-light text-white">{simulatorState.cyclesCompleted}</p>
                  <p className="text-sm text-gray-500 mt-1">Completed</p>
                </CardContent>
              </Card>
            </motion.div>

            {/* Strategies Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg text-white">
                    <Settings className="w-5 h-5 text-orange-400" />
                    Strategies
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-light text-white">{simulatorState.strategies.length}</p>
                  <p className="text-sm text-gray-500 mt-1">Active</p>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Main Control Section */}
          <div className="grid lg:grid-cols-3 gap-6 mb-8">
            {/* Left Column - Strategy & Deposit */}
            <div className="lg:col-span-2 space-y-6">
              {/* Deposit Funds */}
              <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-xl text-white">Deposit Funds</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-base text-gray-200 font-medium mb-2 block">Amount (USD)</label>
                    <Input
                      type="number"
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(Number(e.target.value))}
                      min={100}
                      step={100}
                      className="bg-gray-800 border-gray-600 text-white text-lg"
                    />
                  </div>
                  <Button 
                    onClick={handleDeposit}
                    className="w-full bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-400 hover:to-blue-500"
                    disabled={isRunning}
                  >
                    <Wallet className="w-4 h-4 mr-2" />
                    Deposit
                  </Button>
                </CardContent>
              </Card>

              {/* Strategy Configurator */}
              <StrategyConfigurator
                onStrategyChange={handleStrategyAdd}
                onAIHelp={handleAIHelp}
                existingStrategies={simulatorState.strategies}
              />

              {/* Execute Button */}
              <Card className="bg-gradient-to-br from-purple-900/20 to-pink-900/20 border-purple-800/30">
                <CardContent className="pt-6">
                  <Button 
                    onClick={runCycle}
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 py-6 text-lg"
                    disabled={isRunning || simulatorState.strategies.length === 0}
                  >
                    {isRunning ? (
                      <>
                        <Activity className="w-5 h-5 mr-2 animate-spin" />
                        Executing Cycles...
                      </>
                    ) : (
                      <>
                        <Play className="w-5 h-5 mr-2" />
                        Execute All Strategies
                      </>
                    )}
                  </Button>
                  {simulatorState.strategies.length === 0 && (
                    <p className="text-xs text-gray-500 text-center mt-2">Configure at least one strategy first</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Right Column - NFT, Referrals, AI */}
            <div className="space-y-6">
              <NFTPurchase
                currentNFT={simulatorState.nft}
                onPurchase={handleNFTPurchase}
                balance={simulatorState.balance}
              />

              <ReferralDashboard
                referralData={simulatorState.referrals}
                userId={user?.id}
              />

              {showAI && aiContext && (
                <AIAssistant
                  context={aiContext.context}
                  data={aiContext}
                  onResult={handleAIResult}
                />
              )}

              {!showAI && (
                <Button
                  onClick={() => setShowAI(true)}
                  variant="outline"
                  className="w-full border-teal-500/30 hover:bg-teal-500/10"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Open AI Assistant
                </Button>
              )}

              {simulatorState.aiCosts > 0 && (
                <Card className="bg-yellow-900/10 border-yellow-800/30">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <p className="text-sm text-gray-400 mb-1">Total AI Costs</p>
                      <p className="text-2xl font-light text-yellow-400">${simulatorState.aiCosts.toFixed(4)}</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Card className="bg-gradient-to-br from-green-900/20 to-gray-900/40 border-green-800/30">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400 mb-1">Total Profit</p>
                    <p className="text-2xl font-light text-green-400">
                      ${simulatorState.totalProfit.toFixed(2)}
                    </p>
                  </div>
                  <TrendingUp className="w-10 h-10 text-green-400 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-red-900/20 to-gray-900/40 border-red-800/30">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400 mb-1">Total Loss</p>
                    <p className="text-2xl font-light text-red-400">
                      ${simulatorState.totalLoss.toFixed(2)}
                    </p>
                  </div>
                  <TrendingDown className="w-10 h-10 text-red-400 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* LOOP Token Economics */}
          <LoopEconomics
            totalLoopMinted={simulatorState.loopBalance}
            totalProfit={simulatorState.totalProfit}
            totalLoss={simulatorState.totalLoss}
          />

          {/* Backtesting Panel */}
          <BacktestingPanel 
            strategies={simulatorState.strategies}
            onBacktestComplete={(results) => console.log('Backtest completed:', results)}
          />

          {/* Cycle History with Export */}
          <CycleHistory history={simulatorState.history} />

          {/* Disclaimer */}
          <Card className="bg-yellow-900/10 border-yellow-800/30">
            <CardContent className="pt-6">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-yellow-400 font-medium mb-2">Simulation Only</p>
                  <p className="text-sm text-gray-400 leading-relaxed">
                    This is a demonstration of YieldLoop's mechanics with simulated data. Real trading involves actual risk of loss. 
                    Results shown here do not predict or guarantee future performance.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}