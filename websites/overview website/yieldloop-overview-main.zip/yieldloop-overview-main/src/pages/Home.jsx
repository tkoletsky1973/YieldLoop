import React from 'react';
import Navigation from '@/components/landing/Navigation';
import Hero from '@/components/landing/Hero';
import Principles from '@/components/landing/Principles';
import HowItWorks from '@/components/landing/HowItWorks';
import YieldEngines from '@/components/landing/YieldEngines';
import NFTProgram from '@/components/landing/NFTProgram';
import ReferralProgram from '@/components/landing/ReferralProgram';
import LoopToken from '@/components/landing/LoopToken';
import WhoIsItFor from '@/components/landing/WhoIsItFor';
import Footer from '@/components/landing/Footer';
import ScrollIndicator from '@/components/landing/ScrollIndicator';
import SEO from '@/components/SEO';

export default function Home() {
  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white overflow-x-hidden">
      <SEO 
        title="Home"
        description="YieldLoop - A system that doesn't lie about whether it worked. Cycle-based trading with verified profit only, no emissions, and non-custodial vaults."
        keywords="YieldLoop, DeFi, yield farming, trading, cryptocurrency, non-custodial, blockchain, verified profit, cycle-based trading"
      />
      <Navigation currentPage="Home" />
      <ScrollIndicator />
      <main className="pt-16">
        <section id="hero" aria-label="Hero section">
          <Hero />
        </section>
        <section id="principles" aria-label="Core principles">
          <Principles />
        </section>
        <section id="how-it-works" aria-label="How it works">
          <HowItWorks />
        </section>
        <section id="yield-engines" aria-label="Yield engines">
          <YieldEngines />
        </section>
        <section id="nft-program" aria-label="NFT program">
          <NFTProgram />
        </section>
        <section id="referral-program" aria-label="Referral program">
          <ReferralProgram />
        </section>
        <section id="loop-token" aria-label="LOOP token">
          <LoopToken />
        </section>
        <section id="who-is-it-for" aria-label="Target audience">
          <WhoIsItFor />
        </section>
        <Footer />
      </main>
    </div>
  );
}