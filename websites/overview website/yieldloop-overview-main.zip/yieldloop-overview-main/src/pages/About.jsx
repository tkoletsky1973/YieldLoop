import React from 'react';
import { motion } from 'framer-motion';
import Navigation from '@/components/landing/Navigation';
import Footer from '@/components/landing/Footer';
import { Anchor, Wrench, Shield, Linkedin, Mail, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SEO from '@/components/SEO';

export default function About() {
  const roadmapItems = [
    {
      title: "Cross-Chain Expansion",
      description: "Enable YieldLoop to operate across multiple blockchain networks, increasing accessibility and diversifying execution opportunities while maintaining the same strict accountability standards."
    },
    {
      title: "AI-Assisted Strategy Configuration",
      description: "Provide optional AI guidance to help users understand and configure their strategy parameters before committing capital. The AI will offer suggestions and risk assessments, but all final decisions remain with the user.",
      note: "Advisory only. No automated execution. Risk disclosures mandatory."
    },
    {
      title: "Enhanced Strategy Modules",
      description: "Expand the library of available strategies while maintaining deterministic execution and hard boundaries. Each module undergoes rigorous testing before deployment."
    },
    {
      title: "Advanced Analytics Dashboard",
      description: "Provide detailed cycle-by-cycle performance data, transparent attribution, and historical verification tools to give users complete visibility into system behavior."
    },
    {
      title: "Community Governance",
      description: "Enable Governor NFT holders to participate in specific platform decisions, including strategy approval, parameter adjustments, and fee structure modifications."
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white">
      <SEO 
        title="About Todd Koletsky"
        description="Learn about Todd Koletsky, founder of YieldLoop - a systems engineer with Navy, manufacturing, and DeFi experience building honest, proof-based trading systems."
        keywords="Todd Koletsky, YieldLoop founder, DeFi engineer, systems design, blockchain development, cycle-based trading"
      />
      <Navigation currentPage="About" />
      
      <main className="py-20 px-6 pt-32">
        <div className="max-w-4xl mx-auto">
          {/* Founder Bio Section */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-20"
          >
            <div className="text-center mb-12">
              <p className="text-xs uppercase tracking-[0.3em] text-teal-500 mb-4">The Builder</p>
              <h1 className="text-4xl md:text-6xl font-light text-white mb-6">
                Todd <span className="text-gray-500">Koletsky</span>
              </h1>
              <p className="text-gray-400 font-light">Founder & Systems Engineer</p>
            </div>

            <div className="relative">
              <div className="p-8 md:p-12 rounded-2xl bg-gradient-to-br from-gray-900/80 to-gray-900/40 border border-gray-800/50">
                {/* Career highlights */}
                <div className="grid md:grid-cols-3 gap-6 mb-10">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-teal-500/20 flex items-center justify-center flex-shrink-0">
                      <Anchor className="w-5 h-5 text-teal-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium mb-1">U.S. Navy</p>
                      <p className="text-gray-500 text-sm font-light">Naval engineer, propulsion systems, damage control</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                      <Wrench className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium mb-1">Manufacturing</p>
                      <p className="text-gray-500 text-sm font-light">Maintenance & production manager, plant automation</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                      <Shield className="w-5 h-5 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium mb-1">DeFi</p>
                      <p className="text-gray-500 text-sm font-light">Systems analysis, structural scrutiny, proof-based design</p>
                    </div>
                  </div>
                </div>

                {/* Bio text */}
                <div className="space-y-4 text-gray-400 font-light leading-relaxed">
                  <p>
                    Todd Koletsky is a systems-focused engineer and operations leader with a career rooted in 
                    <span className="text-gray-300"> real-world accountability, not speculation</span>.
                  </p>

                  <p>
                    He began his professional life in the U.S. Navy, rising through the ranks as a naval deck-plate engineer. 
                    His hands-on experience spans metal fabrication, welding, machining, and mechanical repair, evolving into 
                    full responsibility for marine propulsion systems, damage control, and first-responder operations. This work 
                    demanded precision under pressure, strict safety discipline, and a zero-tolerance approach to failure.
                  </p>

                  <p>
                    Following his naval career, Todd transitioned into civilian industry, where he ultimately served as a maintenance 
                    and production manager in a highly automated manufacturing environment. In that role, he was responsible for plant 
                    automation, mechanical reliability, preventative maintenance, and production readiness, ensuring that equipment, 
                    personnel, and processes consistently met operational targets. Success was measured in 
                    <span className="text-gray-300"> uptime, output, and accountability</span>—not narratives.
                  </p>

                  <p>
                    His entry into DeFi came not from speculation, but from scrutiny. After encountering the structural misalignment, 
                    incentive abuse, and opacity common across much of the space, Todd focused on identifying where real yield, 
                    legitimate trades, and verifiable outcomes actually occur. YieldLoop emerged from that analysis—not as a promise 
                    of easy returns, but as an attempt to build a system governed by 
                    <span className="text-gray-300"> proof, containment, and mechanical honesty</span>.
                  </p>
                </div>

                {/* Bottom statement */}
                <div className="mt-10 pt-8 border-t border-gray-800/50">
                  <p className="text-xl md:text-2xl font-light text-gray-300 text-center mb-3">
                    YieldLoop is not designed to impress.
                  </p>
                  <p className="text-xl md:text-2xl font-light text-white text-center mb-6">
                    It is designed to <span className="text-teal-400">function</span>.
                  </p>
                  <p className="text-gray-400 font-light text-center max-w-2xl mx-auto mb-8">
                    Todd's goal is simple: to give participants an honest shot at an honest system—one that behaves predictably, 
                    discloses risk clearly, and earns trust through execution rather than marketing.
                  </p>

                  {/* Contact buttons */}
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-8">
                    <Button 
                      asChild
                      className="group px-6 py-6 text-base bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white rounded-full border-0 transition-all duration-300"
                    >
                      <a href="https://www.linkedin.com/in/todd-koletsky-3880052b" target="_blank" rel="noopener noreferrer">
                        <Linkedin className="mr-2 w-4 h-4" />
                        Connect on LinkedIn
                      </a>
                    </Button>
                    
                    <Button 
                      asChild
                      variant="outline"
                      className="px-6 py-6 text-base bg-transparent border border-gray-700 text-gray-300 hover:bg-white/5 hover:border-gray-600 rounded-full transition-all duration-300"
                    >
                      <a href="mailto:founder@yieldloop.io">
                        <Mail className="mr-2 w-4 h-4" />
                        Email Todd
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Roadmap Section */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mb-20"
          >
            <div className="text-center mb-12">
              <p className="text-xs uppercase tracking-[0.3em] text-blue-500 mb-4">Future Development</p>
              <h2 className="text-3xl md:text-5xl font-light text-white mb-6">
                The <span className="bg-gradient-to-r from-blue-400 to-teal-500 bg-clip-text text-transparent">Roadmap</span>
              </h2>
              <p className="text-gray-400 font-light max-w-2xl mx-auto">
                Planned enhancements that maintain YieldLoop's core principles: transparency, accountability, and mechanical honesty.
              </p>
            </div>

            <div className="space-y-6">
              {roadmapItems.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                  className="p-6 rounded-xl bg-gray-900/60 border border-gray-800/50 hover:border-gray-700/50 transition-all"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <CheckCircle2 className="w-4 h-4 text-blue-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-medium text-white mb-2">{item.title}</h3>
                      <p className="text-gray-400 font-light leading-relaxed">{item.description}</p>
                      {item.note && (
                        <div className="mt-3 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                          <p className="text-xs text-yellow-400 font-light">{item.note}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-10 p-6 rounded-xl bg-teal-500/10 border border-teal-500/30">
              <p className="text-sm text-gray-400 text-center font-light">
                <span className="text-teal-400">No promises. No timelines.</span> Development proceeds as testing validates functionality. 
                Features launch when they're ready, not when they're hyped.
              </p>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}