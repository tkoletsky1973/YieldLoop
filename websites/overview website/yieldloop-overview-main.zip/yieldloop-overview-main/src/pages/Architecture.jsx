import React from 'react';
import { motion } from 'framer-motion';
import Navigation from '@/components/landing/Navigation';
import CycleFlowDiagram from '@/components/diagrams/CycleFlowDiagram';
import SystemArchitectureDiagram from '@/components/diagrams/SystemArchitectureDiagram';
import LoopMintingDiagram from '@/components/diagrams/LoopMintingDiagram';
import FeeDistributionDiagram from '@/components/diagrams/FeeDistributionDiagram';
import SystemRecyclingDiagram from '@/components/diagrams/SystemRecyclingDiagram';
import Footer from '@/components/landing/Footer';
import SEO from '@/components/SEO';

export default function Architecture() {
  return (
    <div className="min-h-screen bg-[#0a0f1a] text-white">
      <SEO 
        title="System Architecture"
        description="Visual representations of YieldLoop's architecture - from cycle execution to LOOP minting and system sustainability. Explore detailed diagrams of our cycle-based trading platform."
        keywords="YieldLoop architecture, system design, cycle flow, LOOP minting, fee distribution, DeFi platform design"
      />
      <Navigation currentPage="Architecture" />
      <main className="py-20 px-6 pt-32">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h1 className="text-4xl md:text-6xl font-light text-white mb-6">
              System <span className="bg-gradient-to-r from-teal-400 to-blue-500 bg-clip-text text-transparent">Architecture</span>
            </h1>
            <p className="text-gray-400 text-lg font-light max-w-2xl mx-auto">
              Visual representations of how YieldLoop operates, from cycle execution to LOOP minting and system sustainability.
            </p>
          </motion.div>

          {/* Diagrams */}
          <div className="space-y-24">
            <article aria-labelledby="cycle-flow">
              <CycleFlowDiagram />
            </article>
            <article aria-labelledby="system-architecture">
              <SystemArchitectureDiagram />
            </article>
            <article aria-labelledby="loop-minting">
              <LoopMintingDiagram />
            </article>
            <article aria-labelledby="fee-distribution">
              <FeeDistributionDiagram />
            </article>
            <article aria-labelledby="system-recycling">
              <SystemRecyclingDiagram />
            </article>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}